# Deployment Guide

## Prerequisites

- Node.js 18 or higher
- npm or yarn
- Supabase account
- Git

## Environment Setup

1. Create a `.env` file in the project root:

```env
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

2. Get these values from your Supabase project dashboard:
   - Go to Settings > API
   - Copy the Project URL and anon/public key

## Database Setup

The database schema is located in `supabase/migrations/`.

### Option 1: Using Supabase CLI (Recommended)

```bash
# Install Supabase CLI
npm install -g supabase

# Link to your project
supabase link --project-ref your-project-ref

# Push migrations
supabase db push
```

### Option 2: Manual Setup

1. Go to your Supabase project dashboard
2. Navigate to SQL Editor
3. Copy and paste the migration file content
4. Execute the SQL

## Local Development

1. Install dependencies:
```bash
npm install
```

2. Start development server:
```bash
npm run dev
```

3. Open browser at `http://localhost:5173`

## Production Build

1. Build the application:
```bash
npm run build
```

2. Test production build locally:
```bash
npm run preview
```

## Deployment Options

### Option 1: Vercel

1. Install Vercel CLI:
```bash
npm install -g vercel
```

2. Deploy:
```bash
vercel
```

3. Add environment variables in Vercel dashboard

### Option 2: Netlify

1. Build the project:
```bash
npm run build
```

2. Deploy the `dist` folder to Netlify

3. Add environment variables in Netlify dashboard

### Option 3: Custom Server

1. Build the project:
```bash
npm run build
```

2. Serve the `dist` folder with any static file server:
```bash
npm install -g serve
serve -s dist
```

## Environment Variables

Required variables for production:

- `VITE_SUPABASE_URL`: Your Supabase project URL
- `VITE_SUPABASE_ANON_KEY`: Your Supabase anonymous key

## Post-Deployment

1. Test authentication flow
2. Verify database connections
3. Test all game functionalities
4. Check leaderboard and statistics
5. Monitor error logs

## Troubleshooting

### Build Errors

- Clear node_modules and reinstall: `rm -rf node_modules && npm install`
- Clear build cache: `rm -rf dist`

### Database Connection Issues

- Verify environment variables
- Check Supabase project status
- Ensure RLS policies are correctly set

### Authentication Issues

- Confirm Supabase auth settings
- Check email provider configuration
- Verify redirect URLs in Supabase dashboard

## Monitoring

- Enable Supabase logging
- Set up error tracking (Sentry, etc.)
- Monitor database performance
- Track user analytics

## Security Checklist

- [ ] Environment variables secured
- [ ] RLS policies enabled on all tables
- [ ] HTTPS enabled in production
- [ ] CORS configured properly
- [ ] Rate limiting implemented
- [ ] Regular security updates
