# Project Structure

## Directory Tree

```
M6rDev/
├── .vscode/
│   └── settings.json           # Editor configuration
├── dist/                       # Build output (generated)
├── node_modules/              # Dependencies (generated)
├── src/
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Header.tsx     # Navigation header with scroll behavior
│   │   │   └── Footer.tsx     # Site footer with social links
│   │   ├── sections/
│   │   │   ├── Hero.tsx       # Landing section with profile
│   │   │   ├── Projects.tsx   # Project showcase grid
│   │   │   ├── Skills.tsx     # Categorized skills display
│   │   │   └── Contact.tsx    # Contact form with validation
│   │   └── ui/
│   │       ├── Badge.tsx      # Tag/label component
│   │       ├── Button.tsx     # Button with variants
│   │       ├── Card.tsx       # Container component
│   │       ├── ErrorMessage.tsx  # Error state display
│   │       ├── LoadingSpinner.tsx # Loading indicator
│   │       └── Section.tsx    # Page section wrapper
│   ├── config/
│   │   └── constants.ts       # App configuration and constants
│   ├── hooks/
│   │   ├── useProjects.ts     # Projects data fetching
│   │   ├── useSkills.ts       # Skills data fetching
│   │   └── useProfileInfo.ts  # Profile data fetching
│   ├── lib/
│   │   └── supabase.ts        # Supabase client configuration
│   ├── types/
│   │   └── index.ts           # TypeScript type definitions
│   ├── utils/
│   │   ├── cn.ts              # Conditional className utility
│   │   ├── format.ts          # Formatting utilities
│   │   ├── scroll.ts          # Scroll utilities
│   │   └── validation.ts      # Input validation utilities
│   ├── App.tsx                # Root application component
│   ├── index.css              # Global styles and Tailwind
│   ├── main.tsx               # Application entry point
│   └── vite-env.d.ts          # Vite type declarations
├── .env                       # Environment variables (not in git)
├── .gitignore                 # Git ignore rules
├── ARCHITECTURE.md            # Detailed architecture documentation
├── CHANGELOG.md               # Version history and changes
├── eslint.config.js           # ESLint configuration
├── index.html                 # HTML entry point
├── package.json               # Dependencies and scripts
├── package-lock.json          # Dependency lock file
├── postcss.config.js          # PostCSS configuration
├── PROJECT_STRUCTURE.md       # This file
├── README.md                  # Project overview and setup
├── tailwind.config.js         # Tailwind CSS configuration
├── tsconfig.json              # TypeScript base configuration
├── tsconfig.app.json          # TypeScript app configuration
├── tsconfig.node.json         # TypeScript node configuration
└── vite.config.ts             # Vite build configuration
```

## File Responsibilities

### Configuration Files

| File | Purpose |
|------|---------|
| `.env` | Environment variables for Supabase connection |
| `eslint.config.js` | Code linting rules and configuration |
| `postcss.config.js` | CSS processing configuration |
| `tailwind.config.js` | Tailwind CSS customization |
| `tsconfig.*.json` | TypeScript compiler options |
| `vite.config.ts` | Build tool configuration |
| `.vscode/settings.json` | Editor settings for consistency |

### Documentation Files

| File | Purpose |
|------|---------|
| `README.md` | Project overview, setup, and usage |
| `ARCHITECTURE.md` | System design and patterns |
| `CHANGELOG.md` | Version history and changes |
| `PROJECT_STRUCTURE.md` | This file - project organization |

### Source Code Organization

#### Components Layer

```
components/
├── ui/          # Reusable UI primitives (Button, Card, Badge)
├── layout/      # Structural components (Header, Footer)
└── sections/    # Feature sections (Hero, Projects, Skills, Contact)
```

**Hierarchy**: `sections` use `layout` and `ui`, `layout` uses `ui`, `ui` is atomic

#### Data Layer

```
├── hooks/       # Custom React hooks for data fetching
├── lib/         # Third-party library configurations
└── types/       # TypeScript type definitions
```

**Flow**: Components → Hooks → Lib → Database

#### Utility Layer

```
utils/
├── cn.ts          # Styling utility
├── format.ts      # Data formatting
├── scroll.ts      # Scroll behavior
└── validation.ts  # Input validation
```

**Usage**: Imported by any layer when needed

## Component Dependency Graph

```
App.tsx
├─ Header.tsx
├─ Hero.tsx
│  ├─ Section.tsx
│  ├─ Button.tsx
│  ├─ LoadingSpinner.tsx
│  └─ useProfileInfo.ts → supabase.ts
├─ Projects.tsx
│  ├─ Section.tsx
│  ├─ Card.tsx
│  ├─ Badge.tsx
│  ├─ LoadingSpinner.tsx
│  ├─ ErrorMessage.tsx
│  └─ useProjects.ts → supabase.ts
├─ Skills.tsx
│  ├─ Section.tsx
│  ├─ Card.tsx
│  ├─ Badge.tsx
│  ├─ LoadingSpinner.tsx
│  ├─ ErrorMessage.tsx
│  └─ useSkills.ts → supabase.ts
├─ Contact.tsx
│  ├─ Section.tsx
│  ├─ Card.tsx
│  ├─ Button.tsx
│  ├─ useProfileInfo.ts → supabase.ts
│  └─ supabase.ts (direct for form submission)
└─ Footer.tsx
   └─ useProfileInfo.ts → supabase.ts
```

## Import Guidelines

### Absolute vs Relative Imports

**Use relative imports** - The project uses relative imports throughout for clarity:

```typescript
// Good
import { Button } from '../../ui/Button';
import { useProjects } from '../../../hooks/useProjects';

// Avoid
import { Button } from '@/components/ui/Button';
```

### Import Order

1. External dependencies (React, libraries)
2. Internal components
3. Hooks
4. Utils and config
5. Types
6. Styles

```typescript
// Example
import { useState } from 'react';
import { Button } from '../ui/Button';
import { useProjects } from '../../hooks/useProjects';
import { cn } from '../../utils/cn';
import type { Project } from '../../types';
```

## Code Organization Principles

### Single Responsibility

Each file should have one clear purpose:
- `Button.tsx` - Only button component
- `useProjects.ts` - Only project data fetching
- `format.ts` - Only formatting utilities

### Separation of Concerns

- **UI Components** - Presentation only, minimal logic
- **Hooks** - Data fetching and state management
- **Utils** - Pure functions, no side effects
- **Types** - Type definitions only

### DRY (Don't Repeat Yourself)

- Reusable components in `ui/`
- Shared utilities in `utils/`
- Common types in `types/`
- Shared config in `config/`

### Naming Conventions

| Type | Convention | Example |
|------|-----------|---------|
| Components | PascalCase | `Button.tsx` |
| Hooks | camelCase with 'use' prefix | `useProjects.ts` |
| Utils | camelCase | `format.ts` |
| Types | PascalCase | `Project`, `Skill` |
| Constants | SCREAMING_SNAKE_CASE | `APP_CONFIG` |

## Adding New Features

### New Component

1. Determine the appropriate directory (`ui`, `layout`, or `sections`)
2. Create component file with PascalCase name
3. Define prop types with TypeScript
4. Implement component with proper exports
5. Add to parent component or route

### New Data Source

1. Define types in `types/index.ts`
2. Create migration for database table
3. Create custom hook in `hooks/`
4. Use hook in component
5. Handle loading and error states

### New Utility

1. Create function in appropriate `utils/` file
2. Export function with proper types
3. Add JSDoc comments if complex
4. Import where needed

## Testing Structure

When adding tests (future):

```
src/
├── components/
│   └── __tests__/
│       ├── Button.test.tsx
│       └── Card.test.tsx
├── hooks/
│   └── __tests__/
│       └── useProjects.test.ts
└── utils/
    └── __tests__/
        ├── cn.test.ts
        └── format.test.ts
```

## Build Output

```
dist/
├── assets/
│   ├── index-[hash].css    # Compiled and minified CSS
│   └── index-[hash].js     # Compiled and minified JS
└── index.html              # HTML with asset references
```

## Environment-Specific Files

| Environment | File | Purpose |
|-------------|------|---------|
| Development | `.env` | Local environment variables |
| Production | Platform config | Deployment environment variables |
| All | `vite.config.ts` | Build configuration |

## Key Design Decisions

### Why This Structure?

1. **Scalability** - Easy to add new components and features
2. **Maintainability** - Clear organization aids debugging
3. **Collaboration** - Team members can navigate easily
4. **Performance** - Efficient imports and code splitting
5. **Type Safety** - Centralized types prevent conflicts

### Component Organization

- `ui/` - Building blocks, no business logic
- `layout/` - Page structure, minimal logic
- `sections/` - Feature-complete, can include business logic

### No 'pages' Directory

This is a single-page application with section-based navigation, so a `pages/` directory would be misleading.

### Hooks Co-located by Feature

Each major feature (projects, skills, profile) has its own hook, making the relationship between data and UI clear.

## Future Expansion

### Adding Authentication

```
src/
├── contexts/
│   └── AuthContext.tsx
└── hooks/
    ├── useAuth.ts
    └── useUser.ts
```

### Adding Routing

```
src/
├── pages/
│   ├── Home.tsx
│   └── Blog.tsx
└── router/
    └── index.tsx
```

### Adding State Management

```
src/
└── store/
    ├── index.ts
    ├── slices/
    └── hooks/
```

## Maintenance Notes

### Keep Small Files

- Target: 100-200 lines per file
- Extract when a file grows beyond 300 lines
- Split by responsibility, not arbitrarily

### Update Documentation

When making structural changes:
1. Update this file
2. Update ARCHITECTURE.md if patterns change
3. Update README.md if setup changes
4. Add entry to CHANGELOG.md

### Regular Cleanup

- Remove unused imports
- Delete unused files
- Update outdated comments
- Refactor duplicated code
