# Brain Hub - Cognitive Training Games Platform

A comprehensive brain training application featuring multiple cognitive games designed to enhance memory, focus, pattern recognition, and mental agility.

## Features

### 🎮 Four Engaging Games

1. **Memory Match** - Test your visual memory by matching pairs of cards
2. **Number Sequence** - Memorize and repeat increasingly complex number sequences
3. **Word Scramble** - Unscramble words under time pressure to test vocabulary
4. **Pattern Recognition** - Identify patterns in shapes and colors

### 📊 Progress Tracking

- User profiles with total points and games played
- Game session history
- Per-game leaderboards
- High score tracking

### 🔐 User Authentication

- Secure email/password authentication
- User profile management
- Session persistence

## Tech Stack

- **Frontend**: React 19 + TypeScript
- **Build Tool**: Vite
- **Backend**: Supabase (PostgreSQL + Auth)
- **Styling**: Inline CSS with responsive design

## Getting Started

### Prerequisites

- Node.js 18+
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone https://github.com/M6rM6r/sh3l.git
cd sh3l
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
Create a `.env` file in the root directory with:
```
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

4. Run the development server:
```bash
npm run dev
```

5. Build for production:
```bash
npm run build
```

## Database Schema

### Tables

- **profiles**: User profiles with stats
- **game_sessions**: Individual game play records
- **leaderboard**: High scores per game type

All tables include Row Level Security (RLS) policies for secure data access.

## Game Mechanics

### Memory Match
- Match pairs of emoji cards
- Increasing difficulty with more pairs
- Score based on moves and time

### Number Sequence
- Remember sequences of increasing length
- Progressive difficulty
- Lives system

### Word Scramble
- 30-second timer per word
- Skip option (with penalty)
- Increasing word complexity

### Pattern Recognition
- Identify next item in sequence
- Shape and color patterns
- 10 questions per session

## Contributing

Pull requests are welcome! For major changes, please open an issue first to discuss what you would like to change.

## License

MIT
