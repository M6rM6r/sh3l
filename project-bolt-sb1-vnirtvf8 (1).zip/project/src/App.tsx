import { AuthProvider } from './contexts/AuthContext';
import { GameHub } from './components/GameHub';

function App() {
  return (
    <AuthProvider>
      <GameHub />
    </AuthProvider>
  );
}

export default App;
