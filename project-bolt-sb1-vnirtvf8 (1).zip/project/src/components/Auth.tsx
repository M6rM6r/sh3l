import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

interface AuthProps {
  onBack: () => void;
}

export function Auth({ onBack }: AuthProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { signUp, signIn } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isSignUp) {
        await signUp(email, password, username);
      } else {
        await signIn(email, password);
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #0a0a0f 0%, #1a1a2e 50%, #0a0a0f 100%)',
      padding: '20px'
    }}>
      <div style={{
        background: 'rgba(0, 255, 159, 0.05)',
        padding: '40px',
        borderRadius: '0px',
        boxShadow: '0 0 40px rgba(0, 255, 159, 0.3)',
        maxWidth: '400px',
        width: '100%',
        border: '2px solid #00ff9f',
        position: 'relative'
      }}>
        <button
          onClick={onBack}
          style={{
            position: 'absolute',
            top: '20px',
            left: '20px',
            background: 'transparent',
            border: '2px solid #00ff9f',
            color: '#00ff9f',
            padding: '8px 16px',
            cursor: 'pointer',
            fontFamily: 'Courier New, monospace',
            fontWeight: '600',
            transition: 'all 0.3s'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = '#00ff9f';
            e.currentTarget.style.color = '#0a0a0f';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = 'transparent';
            e.currentTarget.style.color = '#00ff9f';
          }}
        >
          {'<'} BACK
        </button>
        <h1 style={{
          fontSize: '32px',
          fontWeight: '700',
          marginTop: '40px',
          textAlign: 'center',
          marginBottom: '10px',
          color: '#00ff9f',
          textShadow: '0 0 20px rgba(0, 255, 159, 0.5)',
          fontFamily: 'Courier New, monospace'
        }}>
          {'>'} AUTH_SYSTEM
        </h1>
        <p style={{
          textAlign: 'center',
          color: '#00ff9f',
          marginBottom: '30px',
          opacity: 0.7,
          fontFamily: 'Courier New, monospace'
        }}>
          [Save progress & compete]
        </p>

        <form onSubmit={handleSubmit}>
          {isSignUp && (
            <div style={{ marginBottom: '20px' }}>
              <label style={{
                display: 'block',
                marginBottom: '8px',
                fontWeight: '600',
                color: '#00ff9f',
                fontFamily: 'Courier New, monospace'
              }}>
                [USERNAME]
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                style={{
                  width: '100%',
                  padding: '12px',
                  border: '2px solid #00ff9f',
                  borderRadius: '0px',
                  fontSize: '16px',
                  boxSizing: 'border-box',
                  transition: 'all 0.3s',
                  background: 'rgba(0, 255, 159, 0.05)',
                  color: '#00ff9f',
                  fontFamily: 'Courier New, monospace'
                }}
                onFocus={(e) => {
                  e.currentTarget.style.boxShadow = '0 0 15px rgba(0, 255, 159, 0.4)';
                }}
                onBlur={(e) => {
                  e.currentTarget.style.boxShadow = 'none';
                }}
              />
            </div>
          )}

          <div style={{ marginBottom: '20px' }}>
            <label style={{
              display: 'block',
              marginBottom: '8px',
              fontWeight: '600',
              color: '#00ff9f',
              fontFamily: 'Courier New, monospace'
            }}>
              [EMAIL]
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              style={{
                width: '100%',
                padding: '12px',
                border: '2px solid #00ff9f',
                borderRadius: '0px',
                fontSize: '16px',
                boxSizing: 'border-box',
                transition: 'all 0.3s',
                background: 'rgba(0, 255, 159, 0.05)',
                color: '#00ff9f',
                fontFamily: 'Courier New, monospace'
              }}
              onFocus={(e) => {
                e.currentTarget.style.boxShadow = '0 0 15px rgba(0, 255, 159, 0.4)';
              }}
              onBlur={(e) => {
                e.currentTarget.style.boxShadow = 'none';
              }}
            />
          </div>

          <div style={{ marginBottom: '20px' }}>
            <label style={{
              display: 'block',
              marginBottom: '8px',
              fontWeight: '600',
              color: '#00ff9f',
              fontFamily: 'Courier New, monospace'
            }}>
              [PASSWORD]
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              style={{
                width: '100%',
                padding: '12px',
                border: '2px solid #00ff9f',
                borderRadius: '0px',
                fontSize: '16px',
                boxSizing: 'border-box',
                transition: 'all 0.3s',
                background: 'rgba(0, 255, 159, 0.05)',
                color: '#00ff9f',
                fontFamily: 'Courier New, monospace'
              }}
              onFocus={(e) => {
                e.currentTarget.style.boxShadow = '0 0 15px rgba(0, 255, 159, 0.4)';
              }}
              onBlur={(e) => {
                e.currentTarget.style.boxShadow = 'none';
              }}
            />
          </div>

          {error && (
            <div style={{
              padding: '12px',
              background: 'rgba(255, 0, 85, 0.1)',
              color: '#ff0055',
              borderRadius: '0px',
              marginBottom: '20px',
              fontSize: '14px',
              border: '2px solid #ff0055',
              fontFamily: 'Courier New, monospace'
            }}>
              [ERROR] {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            style={{
              width: '100%',
              padding: '14px',
              background: '#00ff9f',
              color: '#0a0a0f',
              border: '2px solid #00ff9f',
              borderRadius: '0px',
              fontSize: '16px',
              fontWeight: '600',
              cursor: loading ? 'not-allowed' : 'pointer',
              opacity: loading ? 0.7 : 1,
              transition: 'all 0.3s',
              fontFamily: 'Courier New, monospace',
              boxShadow: '0 0 20px rgba(0, 255, 159, 0.5)',
              textTransform: 'uppercase'
            }}
            onMouseEnter={(e) => {
              if (!loading) {
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = '0 0 30px rgba(0, 255, 159, 0.8)';
              }
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = '0 0 20px rgba(0, 255, 159, 0.5)';
            }}
          >
            {loading ? '[PROCESSING...]' : isSignUp ? '[SIGN UP]' : '[SIGN IN]'}
          </button>
        </form>

        <button
          onClick={() => setIsSignUp(!isSignUp)}
          style={{
            width: '100%',
            marginTop: '15px',
            padding: '10px',
            background: 'transparent',
            color: '#00ff9f',
            border: 'none',
            cursor: 'pointer',
            fontSize: '14px',
            fontWeight: '600',
            fontFamily: 'Courier New, monospace',
            transition: 'opacity 0.3s'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.opacity = '0.7';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.opacity = '1';
          }}
        >
          {isSignUp ? '[Have account? Sign In]' : "[No account? Sign Up]"}
        </button>
      </div>
    </div>
  );
}
