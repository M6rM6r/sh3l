import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { games } from '../data/games';
import type { Profile, GameType } from '../types';
import { MemoryMatch } from './games/MemoryMatch';
import { NumberSequence } from './games/NumberSequence';
import { PipeConnection } from './games/PipeConnection';
import { PatternRecognition } from './games/PatternRecognition';
import { LogicGrid } from './games/LogicGrid';
import { CodeBreaker } from './games/CodeBreaker';
import { TowerOfHanoi } from './games/TowerOfHanoi';
import { ColorHarmony } from './games/ColorHarmony';
import { MathMarathon } from './games/MathMarathon';
import { ShapeShifter } from './games/ShapeShifter';
import { RhythmBlocks } from './games/RhythmBlocks';
import { MazeRunner } from './games/MazeRunner';
import { BubbleSort } from './games/BubbleSort';
import { QuickReflexes } from './games/QuickReflexes';
import { Leaderboard } from './Leaderboard';
import { Statistics } from './Statistics';

type View = 'hub' | 'leaderboard' | 'statistics' | 'auth';

export function GameHub() {
  const { user, signOut } = useAuth();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [selectedGame, setSelectedGame] = useState<GameType | null>(null);
  const [currentView, setCurrentView] = useState<View>('hub');

  useEffect(() => {
    if (user) {
      loadProfile();
    }
  }, [user]);

  const loadProfile = async () => {
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user?.id)
      .maybeSingle();

    if (data) {
      setProfile(data);
    }
  };

  const handleGameComplete = async (score: number, level: number, duration: number) => {
    if (!selectedGame) return;

    if (user) {
      await supabase.from('game_sessions').insert({
        user_id: user.id,
        game_type: selectedGame,
        score,
        level,
        duration_seconds: duration,
        completed: true,
      });

      const { data: leaderboardEntry } = await supabase
        .from('leaderboard')
        .select('high_score')
        .eq('user_id', user.id)
        .eq('game_type', selectedGame)
        .maybeSingle();

      if (!leaderboardEntry || score > leaderboardEntry.high_score) {
        await supabase
          .from('leaderboard')
          .upsert({
            user_id: user.id,
            game_type: selectedGame,
            high_score: score,
            updated_at: new Date().toISOString(),
          });
      }

      await supabase
        .from('profiles')
        .update({
          total_points: (profile?.total_points || 0) + score,
          games_played: (profile?.games_played || 0) + 1,
          updated_at: new Date().toISOString(),
        })
        .eq('id', user.id);

      loadProfile();
    }

    setSelectedGame(null);
  };

  if (selectedGame) {
    return (
      <div>
        {selectedGame === 'memory_match' && (
          <MemoryMatch onComplete={handleGameComplete} onBack={() => setSelectedGame(null)} />
        )}
        {selectedGame === 'number_sequence' && (
          <NumberSequence onComplete={handleGameComplete} onBack={() => setSelectedGame(null)} />
        )}
        {selectedGame === 'pipe_connection' && (
          <PipeConnection onComplete={handleGameComplete} onBack={() => setSelectedGame(null)} />
        )}
        {selectedGame === 'pattern_recognition' && (
          <PatternRecognition onComplete={handleGameComplete} onBack={() => setSelectedGame(null)} />
        )}
        {selectedGame === 'logic_grid' && (
          <LogicGrid onComplete={handleGameComplete} onBack={() => setSelectedGame(null)} />
        )}
        {selectedGame === 'code_breaker' && (
          <CodeBreaker onComplete={handleGameComplete} onBack={() => setSelectedGame(null)} />
        )}
        {selectedGame === 'tower_of_hanoi' && (
          <TowerOfHanoi onComplete={handleGameComplete} onBack={() => setSelectedGame(null)} />
        )}
        {selectedGame === 'color_harmony' && (
          <ColorHarmony onComplete={handleGameComplete} onBack={() => setSelectedGame(null)} />
        )}
        {selectedGame === 'math_marathon' && (
          <MathMarathon onComplete={handleGameComplete} onBack={() => setSelectedGame(null)} />
        )}
        {selectedGame === 'shape_shifter' && (
          <ShapeShifter onComplete={handleGameComplete} onBack={() => setSelectedGame(null)} />
        )}
        {selectedGame === 'rhythm_blocks' && (
          <RhythmBlocks onComplete={handleGameComplete} onBack={() => setSelectedGame(null)} />
        )}
        {selectedGame === 'maze_runner' && (
          <MazeRunner onComplete={handleGameComplete} onBack={() => setSelectedGame(null)} />
        )}
        {selectedGame === 'bubble_sort' && (
          <BubbleSort onComplete={handleGameComplete} onBack={() => setSelectedGame(null)} />
        )}
        {selectedGame === 'quick_reflexes' && (
          <QuickReflexes onComplete={handleGameComplete} onBack={() => setSelectedGame(null)} />
        )}
      </div>
    );
  }

  if (currentView === 'leaderboard') {
    return <Leaderboard onBack={() => setCurrentView('hub')} />;
  }

  if (currentView === 'statistics' && user) {
    return <Statistics onBack={() => setCurrentView('hub')} />;
  }

  return (
    <div style={{
      minHeight: '100dvh',
      background: 'linear-gradient(135deg, #0a0a0f 0%, #1a1a2e 50%, #0a0a0f 100%)',
      padding: '15px',
      paddingBottom: '30px'
    }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '30px',
          flexWrap: 'wrap',
          gap: '15px',
          borderBottom: '2px solid #00ff9f',
          paddingBottom: '20px'
        }}>
          <div>
            <h1 style={{
              fontSize: 'clamp(20px, 5vw, 36px)',
              fontWeight: '700',
              margin: '0',
              color: '#00ff9f',
              textShadow: '0 0 20px rgba(0, 255, 159, 0.5)',
              fontFamily: 'Courier New, monospace'
            }}>
              {'>'} BRAIN_HUB.exe
            </h1>
            <p style={{ color: '#00ff9f', margin: '5px 0 0 0', opacity: 0.7, fontFamily: 'Courier New, monospace', fontSize: 'clamp(11px, 2.5vw, 14px)' }}>
              {user ? `[USER: ${profile?.username || 'Anonymous'}]` : '[GUEST MODE]'}
            </p>
          </div>
          {user && (
            <button
              onClick={() => signOut()}
              style={{
                padding: '10px 16px',
                background: 'transparent',
                border: '2px solid #ff0055',
                borderRadius: '0px',
                cursor: 'pointer',
                fontWeight: '600',
                transition: 'all 0.3s',
                color: '#ff0055',
                fontFamily: 'Courier New, monospace',
                boxShadow: '0 0 10px rgba(255, 0, 85, 0.3)',
                fontSize: 'clamp(12px, 2.5vw, 14px)',
                minHeight: '44px',
                touchAction: 'manipulation'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = '#ff0055';
                e.currentTarget.style.color = '#0a0a0f';
                e.currentTarget.style.boxShadow = '0 0 20px rgba(255, 0, 85, 0.6)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = '#ff0055';
                e.currentTarget.style.boxShadow = '0 0 10px rgba(255, 0, 85, 0.3)';
              }}
            >
              [LOGOUT]
            </button>
          )}
        </div>

        <div style={{
          display: 'flex',
          gap: '15px',
          marginBottom: '30px',
          justifyContent: 'center',
          flexWrap: 'wrap'
        }}>
          {user && (
            <>
              <button
                onClick={() => setCurrentView('statistics')}
                style={{
                  padding: '12px 24px',
                  background: 'rgba(0, 255, 159, 0.1)',
                  border: '2px solid #00ff9f',
                  borderRadius: '0px',
                  cursor: 'pointer',
                  fontWeight: '600',
                  transition: 'all 0.3s',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  color: '#00ff9f',
                  fontFamily: 'Courier New, monospace',
                  boxShadow: '0 0 10px rgba(0, 255, 159, 0.3)'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = '#00ff9f';
                  e.currentTarget.style.color = '#0a0a0f';
                  e.currentTarget.style.boxShadow = '0 0 20px rgba(0, 255, 159, 0.6)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'rgba(0, 255, 159, 0.1)';
                  e.currentTarget.style.color = '#00ff9f';
                  e.currentTarget.style.boxShadow = '0 0 10px rgba(0, 255, 159, 0.3)';
                }}
              >
                [STATS]
              </button>
              <button
                onClick={() => setCurrentView('leaderboard')}
                style={{
                  padding: '12px 24px',
                  background: 'rgba(0, 255, 159, 0.1)',
                  border: '2px solid #00ff9f',
                  borderRadius: '0px',
                  cursor: 'pointer',
                  fontWeight: '600',
                  transition: 'all 0.3s',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  color: '#00ff9f',
                  fontFamily: 'Courier New, monospace',
                  boxShadow: '0 0 10px rgba(0, 255, 159, 0.3)'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = '#00ff9f';
                  e.currentTarget.style.color = '#0a0a0f';
                  e.currentTarget.style.boxShadow = '0 0 20px rgba(0, 255, 159, 0.6)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'rgba(0, 255, 159, 0.1)';
                  e.currentTarget.style.color = '#00ff9f';
                  e.currentTarget.style.boxShadow = '0 0 10px rgba(0, 255, 159, 0.3)';
                }}
              >
                [LEADERBOARD]
              </button>
            </>
          )}
        </div>

        {user && (
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))',
            gap: '12px',
            marginBottom: '25px'
          }}>
            <div style={{
              background: 'rgba(0, 255, 159, 0.05)',
              padding: '16px',
              borderRadius: '0px',
              boxShadow: '0 0 20px rgba(0, 255, 159, 0.2)',
              border: '2px solid #00ff9f'
            }}>
              <div style={{ fontSize: 'clamp(11px, 2.5vw, 14px)', color: '#00ff9f', marginBottom: '5px', fontFamily: 'Courier New, monospace', opacity: 0.7 }}>
                [TOTAL_POINTS]
              </div>
              <div style={{
                fontSize: 'clamp(24px, 6vw, 32px)',
                fontWeight: '700',
                color: '#00ff9f',
                fontFamily: 'Courier New, monospace',
                textShadow: '0 0 10px rgba(0, 255, 159, 0.5)'
              }}>
                {profile?.total_points || 0}
              </div>
            </div>
            <div style={{
              background: 'rgba(0, 255, 159, 0.05)',
              padding: '16px',
              borderRadius: '0px',
              boxShadow: '0 0 20px rgba(0, 255, 159, 0.2)',
              border: '2px solid #00ff9f'
            }}>
              <div style={{ fontSize: 'clamp(11px, 2.5vw, 14px)', color: '#00ff9f', marginBottom: '5px', fontFamily: 'Courier New, monospace', opacity: 0.7 }}>
                [GAMES_PLAYED]
              </div>
              <div style={{
                fontSize: 'clamp(24px, 6vw, 32px)',
                fontWeight: '700',
                color: '#00ff9f',
                fontFamily: 'Courier New, monospace',
                textShadow: '0 0 10px rgba(0, 255, 159, 0.5)'
              }}>
                {profile?.games_played || 0}
              </div>
            </div>
          </div>
        )}

        <h2 style={{
          fontSize: 'clamp(18px, 4vw, 24px)',
          fontWeight: '700',
          marginBottom: '15px',
          color: '#00ff9f',
          fontFamily: 'Courier New, monospace',
          textShadow: '0 0 10px rgba(0, 255, 159, 0.5)'
        }}>
          {'>'} SELECT_GAME:
        </h2>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(min(280px, 100%), 1fr))',
          gap: '15px'
        }}>
          {games.map((game) => (
            <div
              key={game.id}
              onClick={() => setSelectedGame(game.id)}
              style={{
                background: 'rgba(0, 255, 159, 0.05)',
                borderRadius: '0px',
                padding: '20px',
                cursor: 'pointer',
                transition: 'all 0.3s',
                boxShadow: '0 0 20px rgba(0, 255, 159, 0.2)',
                border: `2px solid ${game.color}`,
                position: 'relative',
                overflow: 'hidden',
                minHeight: '160px',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                touchAction: 'manipulation',
                WebkitTapHighlightColor: 'transparent'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'scale(1.02)';
                e.currentTarget.style.boxShadow = `0 0 40px ${game.color}80`;
                e.currentTarget.style.background = `${game.color}15`;
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'scale(1)';
                e.currentTarget.style.boxShadow = '0 0 20px rgba(0, 255, 159, 0.2)';
                e.currentTarget.style.background = 'rgba(0, 255, 159, 0.05)';
              }}
              onTouchStart={(e) => {
                e.currentTarget.style.transform = 'scale(0.98)';
                e.currentTarget.style.boxShadow = `0 0 40px ${game.color}80`;
                e.currentTarget.style.background = `${game.color}15`;
              }}
              onTouchEnd={(e) => {
                e.currentTarget.style.transform = 'scale(1)';
                e.currentTarget.style.boxShadow = '0 0 20px rgba(0, 255, 159, 0.2)';
                e.currentTarget.style.background = 'rgba(0, 255, 159, 0.05)';
              }}
            >
              <div style={{ fontSize: 'clamp(36px, 8vw, 48px)', marginBottom: '12px', filter: 'drop-shadow(0 0 10px rgba(0, 255, 159, 0.5))', textAlign: 'center' }}>
                {game.icon}
              </div>
              <h3 style={{
                fontSize: 'clamp(16px, 3.5vw, 20px)',
                fontWeight: '700',
                marginBottom: '8px',
                color: game.color,
                fontFamily: 'Courier New, monospace',
                textShadow: `0 0 10px ${game.color}80`,
                textAlign: 'center'
              }}>
                {'>'} {game.name.toUpperCase()}
              </h3>
              <p style={{
                color: '#00ff9f',
                fontSize: 'clamp(12px, 2.5vw, 14px)',
                lineHeight: '1.4',
                opacity: 0.8,
                fontFamily: 'Courier New, monospace',
                textAlign: 'center'
              }}>
                {game.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
