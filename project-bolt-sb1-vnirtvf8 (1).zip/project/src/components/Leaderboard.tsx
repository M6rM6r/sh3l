import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { LeaderboardEntry, GameType } from '../types';
import { games } from '../data/games';

interface LeaderboardProps {
  onBack: () => void;
}

export function Leaderboard({ onBack }: LeaderboardProps) {
  const [selectedGame, setSelectedGame] = useState<GameType>('memory_match');
  const [leaderboardData, setLeaderboardData] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadLeaderboard();
  }, [selectedGame]);

  const loadLeaderboard = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('leaderboard')
      .select(`
        *,
        profiles (username)
      `)
      .eq('game_type', selectedGame)
      .order('high_score', { ascending: false })
      .limit(10);

    if (data) {
      setLeaderboardData(data);
    }
    setLoading(false);
  };

  const selectedGameInfo = games.find(g => g.id === selectedGame);

  return (
    <div style={{ minHeight: '100vh', background: '#f3f4f6', padding: '20px' }}>
      <div style={{ maxWidth: '800px', margin: '0 auto' }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '30px'
        }}>
          <button
            onClick={onBack}
            style={{
              padding: '10px 20px',
              background: 'white',
              border: '2px solid #e5e7eb',
              borderRadius: '10px',
              cursor: 'pointer',
              fontWeight: '600',
              transition: 'all 0.3s'
            }}
          >
            ← Back
          </button>
          <h1 style={{ fontSize: '32px', fontWeight: '700', margin: 0, color: '#1a1a1a' }}>
            Leaderboard
          </h1>
          <div style={{ width: '80px' }}></div>
        </div>

        <div style={{
          display: 'flex',
          gap: '10px',
          marginBottom: '30px',
          flexWrap: 'wrap',
          justifyContent: 'center'
        }}>
          {games.map((game) => (
            <button
              key={game.id}
              onClick={() => setSelectedGame(game.id)}
              style={{
                padding: '10px 20px',
                background: selectedGame === game.id ? game.color : 'white',
                color: selectedGame === game.id ? 'white' : '#666',
                border: `2px solid ${selectedGame === game.id ? game.color : '#e5e7eb'}`,
                borderRadius: '10px',
                cursor: 'pointer',
                fontWeight: '600',
                transition: 'all 0.3s',
                fontSize: '14px'
              }}
            >
              {game.icon} {game.name}
            </button>
          ))}
        </div>

        <div style={{
          background: 'white',
          borderRadius: '20px',
          padding: '30px',
          boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '15px',
            marginBottom: '30px'
          }}>
            <div style={{ fontSize: '48px' }}>{selectedGameInfo?.icon}</div>
            <h2 style={{
              fontSize: '28px',
              fontWeight: '700',
              margin: 0,
              color: selectedGameInfo?.color
            }}>
              {selectedGameInfo?.name}
            </h2>
          </div>

          {loading ? (
            <div style={{ textAlign: 'center', padding: '40px', color: '#666' }}>
              Loading...
            </div>
          ) : leaderboardData.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '40px', color: '#666' }}>
              No scores yet. Be the first to play!
            </div>
          ) : (
            <div>
              {leaderboardData.map((entry, index) => (
                <div
                  key={entry.id}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '20px',
                    borderBottom: index < leaderboardData.length - 1 ? '1px solid #e5e7eb' : 'none',
                    background: index < 3 ? 'rgba(0,0,0,0.02)' : 'transparent',
                    transition: 'background 0.3s'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'rgba(0,0,0,0.05)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = index < 3 ? 'rgba(0,0,0,0.02)' : 'transparent';
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
                    <div style={{
                      fontSize: '24px',
                      fontWeight: '700',
                      color: index === 0 ? '#FFD700' : index === 1 ? '#C0C0C0' : index === 2 ? '#CD7F32' : '#666',
                      minWidth: '40px'
                    }}>
                      {index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `#${index + 1}`}
                    </div>
                    <div>
                      <div style={{ fontWeight: '600', fontSize: '18px', color: '#1a1a1a' }}>
                        {entry.profiles?.username || 'Anonymous'}
                      </div>
                      <div style={{ fontSize: '14px', color: '#666' }}>
                        {new Date(entry.updated_at).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                  <div style={{
                    fontSize: '28px',
                    fontWeight: '700',
                    color: selectedGameInfo?.color
                  }}>
                    {entry.high_score}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
