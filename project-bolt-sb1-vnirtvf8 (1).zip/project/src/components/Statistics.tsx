import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import type { GameSession } from '../types';
import { games } from '../data/games';

interface StatisticsProps {
  onBack: () => void;
}

interface GameStats {
  game_type: string;
  total_plays: number;
  average_score: number;
  best_score: number;
}

export function Statistics({ onBack }: StatisticsProps) {
  const { user } = useAuth();
  const [recentSessions, setRecentSessions] = useState<GameSession[]>([]);
  const [gameStats, setGameStats] = useState<GameStats[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStatistics();
  }, []);

  const loadStatistics = async () => {
    if (!user) return;

    const { data: sessions } = await supabase
      .from('game_sessions')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(10);

    if (sessions) {
      setRecentSessions(sessions);
    }

    const statsPromises = games.map(async (game) => {
      const { data } = await supabase
        .from('game_sessions')
        .select('score')
        .eq('user_id', user.id)
        .eq('game_type', game.id);

      if (data && data.length > 0) {
        const scores = data.map(s => s.score);
        return {
          game_type: game.id,
          total_plays: data.length,
          average_score: Math.round(scores.reduce((a, b) => a + b, 0) / scores.length),
          best_score: Math.max(...scores)
        };
      }
      return {
        game_type: game.id,
        total_plays: 0,
        average_score: 0,
        best_score: 0
      };
    });

    const stats = await Promise.all(statsPromises);
    setGameStats(stats);
    setLoading(false);
  };

  const getGameInfo = (gameType: string) => games.find(g => g.id === gameType);

  return (
    <div style={{ minHeight: '100vh', background: '#f3f4f6', padding: '20px' }}>
      <div style={{ maxWidth: '1000px', margin: '0 auto' }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '30px'
        }}>
          <button
            onClick={onBack}
            style={{
              padding: '10px 20px',
              background: 'white',
              border: '2px solid #e5e7eb',
              borderRadius: '10px',
              cursor: 'pointer',
              fontWeight: '600',
              transition: 'all 0.3s'
            }}
          >
            ← Back
          </button>
          <h1 style={{ fontSize: '32px', fontWeight: '700', margin: 0, color: '#1a1a1a' }}>
            My Statistics
          </h1>
          <div style={{ width: '80px' }}></div>
        </div>

        {loading ? (
          <div style={{
            background: 'white',
            borderRadius: '20px',
            padding: '60px',
            textAlign: 'center',
            color: '#666'
          }}>
            Loading statistics...
          </div>
        ) : (
          <>
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
              gap: '20px',
              marginBottom: '30px'
            }}>
              {gameStats.map((stat) => {
                const gameInfo = getGameInfo(stat.game_type);
                return (
                  <div
                    key={stat.game_type}
                    style={{
                      background: 'white',
                      borderRadius: '20px',
                      padding: '25px',
                      boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
                      borderTop: `4px solid ${gameInfo?.color}`
                    }}
                  >
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '10px',
                      marginBottom: '20px'
                    }}>
                      <span style={{ fontSize: '32px' }}>{gameInfo?.icon}</span>
                      <h3 style={{
                        fontSize: '18px',
                        fontWeight: '700',
                        margin: 0,
                        color: '#1a1a1a'
                      }}>
                        {gameInfo?.name}
                      </h3>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                      <div>
                        <div style={{ fontSize: '12px', color: '#666', marginBottom: '4px' }}>
                          Total Plays
                        </div>
                        <div style={{ fontSize: '24px', fontWeight: '700', color: gameInfo?.color }}>
                          {stat.total_plays}
                        </div>
                      </div>
                      <div>
                        <div style={{ fontSize: '12px', color: '#666', marginBottom: '4px' }}>
                          Best Score
                        </div>
                        <div style={{ fontSize: '20px', fontWeight: '600', color: '#1a1a1a' }}>
                          {stat.best_score}
                        </div>
                      </div>
                      <div>
                        <div style={{ fontSize: '12px', color: '#666', marginBottom: '4px' }}>
                          Average Score
                        </div>
                        <div style={{ fontSize: '20px', fontWeight: '600', color: '#1a1a1a' }}>
                          {stat.average_score}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div style={{
              background: 'white',
              borderRadius: '20px',
              padding: '30px',
              boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
            }}>
              <h2 style={{ fontSize: '24px', fontWeight: '700', marginBottom: '20px', color: '#1a1a1a' }}>
                Recent Games
              </h2>
              {recentSessions.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '40px', color: '#666' }}>
                  No games played yet
                </div>
              ) : (
                <div>
                  {recentSessions.map((session, index) => {
                    const gameInfo = getGameInfo(session.game_type);
                    return (
                      <div
                        key={session.id}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          padding: '15px',
                          borderBottom: index < recentSessions.length - 1 ? '1px solid #e5e7eb' : 'none',
                          transition: 'background 0.3s'
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.background = 'rgba(0,0,0,0.02)';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.background = 'transparent';
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                          <div style={{ fontSize: '32px' }}>{gameInfo?.icon}</div>
                          <div>
                            <div style={{ fontWeight: '600', color: '#1a1a1a' }}>
                              {gameInfo?.name}
                            </div>
                            <div style={{ fontSize: '14px', color: '#666' }}>
                              {new Date(session.created_at).toLocaleString()}
                            </div>
                          </div>
                        </div>
                        <div style={{ textAlign: 'right' }}>
                          <div style={{
                            fontSize: '24px',
                            fontWeight: '700',
                            color: gameInfo?.color
                          }}>
                            {session.score}
                          </div>
                          <div style={{ fontSize: '12px', color: '#666' }}>
                            Level {session.level}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
