import { useState, useEffect } from 'react';

interface CodeBreakerProps {
  onComplete: (score: number, level: number, duration: number) => void;
  onBack: () => void;
}

interface Guess {
  colors: string[];
  correct: number;
  wrongPosition: number;
}

const COLORS = [
  { name: 'Red', hex: '#ef4444' },
  { name: 'Blue', hex: '#3b82f6' },
  { name: 'Green', hex: '#10b981' },
  { name: 'Yellow', hex: '#f59e0b' },
  { name: 'Purple', hex: '#a855f7' },
  { name: 'Pink', hex: '#ec4899' },
  { name: 'Cyan', hex: '#06b6d4' },
  { name: 'Orange', hex: '#f97316' },
];

export function CodeBreaker({ onComplete, onBack }: CodeBreakerProps) {
  const [secretCode, setSecretCode] = useState<string[]>([]);
  const [currentGuess, setCurrentGuess] = useState<string[]>([]);
  const [guesses, setGuesses] = useState<Guess[]>([]);
  const [level, setLevel] = useState(1);
  const [score, setScore] = useState(0);
  const [startTime] = useState(Date.now());
  const [codeLength, setCodeLength] = useState(4);
  const [maxGuesses] = useState(10);
  const [isWon, setIsWon] = useState(false);
  const [isLost, setIsLost] = useState(false);

  useEffect(() => {
    generateCode(level);
  }, [level]);

  const generateCode = (currentLevel: number) => {
    const length = Math.min(4 + Math.floor(currentLevel / 3), 6);
    setCodeLength(length);

    const code: string[] = [];
    for (let i = 0; i < length; i++) {
      const randomColor = COLORS[Math.floor(Math.random() * COLORS.length)];
      code.push(randomColor.hex);
    }

    setSecretCode(code);
    setCurrentGuess(Array(length).fill(''));
    setGuesses([]);
    setIsWon(false);
    setIsLost(false);
  };

  const handleColorSelect = (index: number, color: string) => {
    const newGuess = [...currentGuess];
    newGuess[index] = color;
    setCurrentGuess(newGuess);
  };

  const handleSubmitGuess = () => {
    if (currentGuess.some(c => c === '')) return;

    let correct = 0;
    let wrongPosition = 0;

    const secretCopy = [...secretCode];
    const guessCopy = [...currentGuess];

    for (let i = 0; i < codeLength; i++) {
      if (guessCopy[i] === secretCopy[i]) {
        correct++;
        secretCopy[i] = '';
        guessCopy[i] = '';
      }
    }

    for (let i = 0; i < codeLength; i++) {
      if (guessCopy[i] !== '') {
        const foundIndex = secretCopy.indexOf(guessCopy[i]);
        if (foundIndex !== -1) {
          wrongPosition++;
          secretCopy[foundIndex] = '';
        }
      }
    }

    const newGuess: Guess = {
      colors: [...currentGuess],
      correct,
      wrongPosition
    };

    const newGuesses = [...guesses, newGuess];
    setGuesses(newGuesses);

    if (correct === codeLength) {
      const attempts = newGuesses.length;
      const bonus = Math.max(0, (maxGuesses - attempts) * 50);
      const levelScore = 300 + bonus + (level * 100);
      setScore(score + levelScore);
      setIsWon(true);
    } else if (newGuesses.length >= maxGuesses) {
      setIsLost(true);
    } else {
      setCurrentGuess(Array(codeLength).fill(''));
    }
  };

  const handleNextLevel = () => {
    setLevel(level + 1);
  };

  const handleRetry = () => {
    generateCode(level);
  };

  const handleFinish = () => {
    const duration = Math.floor((Date.now() - startTime) / 1000);
    onComplete(score, level, duration);
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #0a0a0f 0%, #1a1a2e 50%, #0a0a0f 100%)',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center'
    }}>
      <div style={{
        width: '100%',
        maxWidth: '700px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '20px',
        paddingBottom: '20px',
        borderBottom: '2px solid #00ff9f'
      }}>
        <button
          onClick={onBack}
          style={{
            padding: '10px 20px',
            background: 'transparent',
            border: '2px solid #00ff9f',
            borderRadius: '0px',
            cursor: 'pointer',
            fontWeight: '600',
            color: '#00ff9f',
            fontFamily: 'Courier New, monospace',
            transition: 'all 0.3s',
            boxShadow: '0 0 10px rgba(0, 255, 159, 0.3)'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = '#00ff9f';
            e.currentTarget.style.color = '#0a0a0f';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = 'transparent';
            e.currentTarget.style.color = '#00ff9f';
          }}
        >
          {'<'} BACK
        </button>
        <div style={{
          display: 'flex',
          gap: '20px',
          fontFamily: 'Courier New, monospace',
          color: '#00ff9f'
        }}>
          <div>[LEVEL: {level}]</div>
          <div>[SCORE: {score}]</div>
          <div>[ATTEMPTS: {guesses.length}/{maxGuesses}]</div>
        </div>
      </div>

      <h1 style={{
        fontSize: '32px',
        fontWeight: '700',
        marginBottom: '10px',
        color: '#00ff9f',
        textShadow: '0 0 20px rgba(0, 255, 159, 0.5)',
        fontFamily: 'Courier New, monospace',
        textAlign: 'center'
      }}>
        {'>'} CODE_BREAKER
      </h1>

      <p style={{
        color: '#00ff9f',
        opacity: 0.7,
        fontFamily: 'Courier New, monospace',
        marginBottom: '30px',
        textAlign: 'center'
      }}>
        [Crack the {codeLength}-color code]
      </p>

      <div style={{
        background: 'rgba(0, 255, 159, 0.05)',
        padding: '30px',
        border: '2px solid #00ff9f',
        boxShadow: '0 0 30px rgba(0, 255, 159, 0.3)',
        marginBottom: '20px',
        width: '100%',
        maxWidth: '600px'
      }}>
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '12px',
          marginBottom: '30px'
        }}>
          {guesses.map((guess, idx) => (
            <div key={idx} style={{
              display: 'flex',
              alignItems: 'center',
              gap: '15px',
              padding: '10px',
              background: '#1a1a2e',
              border: '1px solid #334155'
            }}>
              <div style={{
                fontFamily: 'Courier New, monospace',
                color: '#00ff9f',
                fontSize: '12px',
                width: '30px'
              }}>
                #{idx + 1}
              </div>
              <div style={{ display: 'flex', gap: '8px', flex: 1 }}>
                {guess.colors.map((color, cIdx) => (
                  <div key={cIdx} style={{
                    width: '40px',
                    height: '40px',
                    background: color,
                    border: '2px solid #334155',
                    boxShadow: `0 0 10px ${color}40`
                  }} />
                ))}
              </div>
              <div style={{
                display: 'flex',
                gap: '10px',
                fontFamily: 'Courier New, monospace',
                fontSize: '14px'
              }}>
                <div style={{
                  padding: '5px 10px',
                  background: '#10b981',
                  color: '#0a0a0f',
                  fontWeight: '700',
                  border: '2px solid #10b981',
                  boxShadow: '0 0 10px rgba(16, 185, 129, 0.5)'
                }}>
                  {guess.correct}
                </div>
                <div style={{
                  padding: '5px 10px',
                  background: '#f59e0b',
                  color: '#0a0a0f',
                  fontWeight: '700',
                  border: '2px solid #f59e0b',
                  boxShadow: '0 0 10px rgba(245, 158, 11, 0.5)'
                }}>
                  {guess.wrongPosition}
                </div>
              </div>
            </div>
          ))}
        </div>

        {!isWon && !isLost && (
          <>
            <div style={{
              marginBottom: '20px',
              padding: '15px',
              background: '#1a1a2e',
              border: '2px solid #334155'
            }}>
              <div style={{
                fontFamily: 'Courier New, monospace',
                color: '#00ff9f',
                fontSize: '12px',
                marginBottom: '15px'
              }}>
                [CURRENT GUESS]
              </div>
              <div style={{ display: 'flex', gap: '10px', justifyContent: 'center', marginBottom: '20px' }}>
                {currentGuess.map((color, idx) => (
                  <div key={idx} style={{
                    width: '50px',
                    height: '50px',
                    background: color || '#0a0a0f',
                    border: `3px solid ${color ? '#00ff9f' : '#334155'}`,
                    boxShadow: color ? `0 0 15px ${color}60` : 'none',
                    transition: 'all 0.3s'
                  }} />
                ))}
              </div>

              <div style={{
                fontFamily: 'Courier New, monospace',
                color: '#00ff9f',
                fontSize: '12px',
                marginBottom: '10px'
              }}>
                [SELECT COLORS]
              </div>
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(4, 1fr)',
                gap: '10px',
                marginBottom: '20px'
              }}>
                {COLORS.map((color) => (
                  <button
                    key={color.hex}
                    onClick={() => {
                      const firstEmpty = currentGuess.indexOf('');
                      if (firstEmpty !== -1) {
                        handleColorSelect(firstEmpty, color.hex);
                      }
                    }}
                    style={{
                      width: '100%',
                      height: '40px',
                      background: color.hex,
                      border: '2px solid #334155',
                      cursor: 'pointer',
                      transition: 'all 0.2s',
                      boxShadow: `0 0 10px ${color.hex}40`
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.borderColor = '#00ff9f';
                      e.currentTarget.style.transform = 'scale(1.05)';
                      e.currentTarget.style.boxShadow = `0 0 20px ${color.hex}80`;
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.borderColor = '#334155';
                      e.currentTarget.style.transform = 'scale(1)';
                      e.currentTarget.style.boxShadow = `0 0 10px ${color.hex}40`;
                    }}
                  />
                ))}
              </div>

              <div style={{ display: 'flex', gap: '10px' }}>
                <button
                  onClick={() => setCurrentGuess(Array(codeLength).fill(''))}
                  style={{
                    flex: 1,
                    padding: '12px',
                    background: 'transparent',
                    border: '2px solid #ef4444',
                    color: '#ef4444',
                    cursor: 'pointer',
                    fontWeight: '600',
                    fontFamily: 'Courier New, monospace',
                    transition: 'all 0.3s'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = '#ef4444';
                    e.currentTarget.style.color = '#0a0a0f';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'transparent';
                    e.currentTarget.style.color = '#ef4444';
                  }}
                >
                  [CLEAR]
                </button>
                <button
                  onClick={handleSubmitGuess}
                  disabled={currentGuess.some(c => c === '')}
                  style={{
                    flex: 2,
                    padding: '12px',
                    background: currentGuess.some(c => c === '') ? '#334155' : '#00ff9f',
                    border: '2px solid #00ff9f',
                    color: currentGuess.some(c => c === '') ? '#666' : '#0a0a0f',
                    cursor: currentGuess.some(c => c === '') ? 'not-allowed' : 'pointer',
                    fontWeight: '700',
                    fontFamily: 'Courier New, monospace',
                    transition: 'all 0.3s',
                    boxShadow: currentGuess.some(c => c === '') ? 'none' : '0 0 15px rgba(0, 255, 159, 0.5)'
                  }}
                  onMouseEnter={(e) => {
                    if (!currentGuess.some(c => c === '')) {
                      e.currentTarget.style.boxShadow = '0 0 25px rgba(0, 255, 159, 0.8)';
                      e.currentTarget.style.transform = 'translateY(-2px)';
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!currentGuess.some(c => c === '')) {
                      e.currentTarget.style.boxShadow = '0 0 15px rgba(0, 255, 159, 0.5)';
                      e.currentTarget.style.transform = 'translateY(0)';
                    }
                  }}
                >
                  [SUBMIT GUESS]
                </button>
              </div>
            </div>
          </>
        )}
      </div>

      <div style={{
        width: '100%',
        maxWidth: '600px',
        padding: '15px',
        background: 'rgba(0, 255, 159, 0.05)',
        border: '2px solid #334155',
        color: '#00ff9f',
        fontFamily: 'Courier New, monospace',
        fontSize: '12px',
        lineHeight: '1.8'
      }}>
        <div style={{ fontWeight: '700', marginBottom: '10px' }}>[FEEDBACK KEY]</div>
        <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{
              width: '20px',
              height: '20px',
              background: '#10b981',
              border: '2px solid #10b981'
            }} />
            <span>Correct color & position</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{
              width: '20px',
              height: '20px',
              background: '#f59e0b',
              border: '2px solid #f59e0b'
            }} />
            <span>Correct color, wrong position</span>
          </div>
        </div>
      </div>

      {isWon && (
        <div style={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          background: 'rgba(0, 0, 0, 0.95)',
          border: '3px solid #00ff9f',
          padding: '40px',
          textAlign: 'center',
          boxShadow: '0 0 50px rgba(0, 255, 159, 0.6)',
          zIndex: 1000
        }}>
          <h2 style={{
            color: '#00ff9f',
            marginBottom: '15px',
            fontFamily: 'Courier New, monospace',
            fontSize: '28px',
            textShadow: '0 0 20px rgba(0, 255, 159, 0.8)'
          }}>
            [CODE CRACKED!]
          </h2>
          <p style={{
            color: '#00ff9f',
            opacity: 0.8,
            fontFamily: 'Courier New, monospace',
            marginBottom: '25px'
          }}>
            Solved in {guesses.length} attempts
          </p>
          <div style={{ display: 'flex', gap: '15px', justifyContent: 'center' }}>
            <button
              onClick={handleNextLevel}
              style={{
                padding: '15px 30px',
                background: '#00ff9f',
                border: '2px solid #00ff9f',
                cursor: 'pointer',
                fontWeight: '600',
                color: '#0a0a0f',
                fontFamily: 'Courier New, monospace',
                fontSize: '16px',
                transition: 'all 0.3s',
                boxShadow: '0 0 20px rgba(0, 255, 159, 0.5)'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.boxShadow = '0 0 30px rgba(0, 255, 159, 0.9)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.boxShadow = '0 0 20px rgba(0, 255, 159, 0.5)';
              }}
            >
              [NEXT LEVEL]
            </button>
            <button
              onClick={handleFinish}
              style={{
                padding: '15px 30px',
                background: 'transparent',
                border: '2px solid #00ff9f',
                cursor: 'pointer',
                fontWeight: '600',
                color: '#00ff9f',
                fontFamily: 'Courier New, monospace',
                fontSize: '16px',
                transition: 'all 0.3s'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = '#00ff9f';
                e.currentTarget.style.color = '#0a0a0f';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = '#00ff9f';
              }}
            >
              [FINISH]
            </button>
          </div>
        </div>
      )}

      {isLost && (
        <div style={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          background: 'rgba(0, 0, 0, 0.95)',
          border: '3px solid #ef4444',
          padding: '40px',
          textAlign: 'center',
          boxShadow: '0 0 50px rgba(239, 68, 68, 0.6)',
          zIndex: 1000
        }}>
          <h2 style={{
            color: '#ef4444',
            marginBottom: '15px',
            fontFamily: 'Courier New, monospace',
            fontSize: '28px',
            textShadow: '0 0 20px rgba(239, 68, 68, 0.8)'
          }}>
            [FAILED]
          </h2>
          <p style={{
            color: '#ef4444',
            opacity: 0.8,
            fontFamily: 'Courier New, monospace',
            marginBottom: '15px'
          }}>
            Out of attempts
          </p>
          <div style={{
            display: 'flex',
            gap: '8px',
            justifyContent: 'center',
            marginBottom: '25px'
          }}>
            {secretCode.map((color, idx) => (
              <div key={idx} style={{
                width: '40px',
                height: '40px',
                background: color,
                border: '2px solid #00ff9f',
                boxShadow: `0 0 15px ${color}60`
              }} />
            ))}
          </div>
          <div style={{ display: 'flex', gap: '15px', justifyContent: 'center' }}>
            <button
              onClick={handleRetry}
              style={{
                padding: '15px 30px',
                background: '#ef4444',
                border: '2px solid #ef4444',
                cursor: 'pointer',
                fontWeight: '600',
                color: '#0a0a0f',
                fontFamily: 'Courier New, monospace',
                fontSize: '16px',
                transition: 'all 0.3s'
              }}
            >
              [RETRY]
            </button>
            <button
              onClick={handleFinish}
              style={{
                padding: '15px 30px',
                background: 'transparent',
                border: '2px solid #00ff9f',
                cursor: 'pointer',
                fontWeight: '600',
                color: '#00ff9f',
                fontFamily: 'Courier New, monospace',
                fontSize: '16px',
                transition: 'all 0.3s'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = '#00ff9f';
                e.currentTarget.style.color = '#0a0a0f';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = '#00ff9f';
              }}
            >
              [FINISH]
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
