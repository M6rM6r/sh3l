import { useState, useEffect } from 'react';

interface LogicGridProps {
  onComplete: (score: number, level: number, duration: number) => void;
  onBack: () => void;
}

type CellState = 'empty' | 'x' | 'check';

interface Clue {
  text: string;
  color: string;
}

export function LogicGrid({ onComplete, onBack }: LogicGridProps) {
  const [grid, setGrid] = useState<CellState[][]>([]);
  const [solution, setSolution] = useState<boolean[][]>([]);
  const [level, setLevel] = useState(1);
  const [score, setScore] = useState(0);
  const [startTime] = useState(Date.now());
  const [clues, setClues] = useState<Clue[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [gridSize, setGridSize] = useState(4);
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    generatePuzzle(level);
  }, [level]);

  const generatePuzzle = (currentLevel: number) => {
    const size = Math.min(4 + Math.floor(currentLevel / 3), 6);
    setGridSize(size);

    const themes = [
      { name: 'Colors', items: ['Red', 'Blue', 'Green', 'Yellow', 'Purple', 'Orange'], colors: ['#ef4444', '#3b82f6', '#10b981', '#f59e0b', '#a855f7', '#f97316'] },
      { name: 'Numbers', items: ['One', 'Two', 'Three', 'Four', 'Five', 'Six'], colors: ['#06b6d4', '#8b5cf6', '#ec4899', '#14b8a6', '#f59e0b', '#ef4444'] },
      { name: 'Letters', items: ['Alpha', 'Beta', 'Gamma', 'Delta', 'Epsilon', 'Zeta'], colors: ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'] },
    ];

    const theme = themes[Math.floor(Math.random() * themes.length)];
    const selectedItems = theme.items.slice(0, size);
    const selectedColors = theme.colors.slice(0, size);

    setCategories(selectedItems);

    const newSolution: boolean[][] = Array(size).fill(null).map(() => Array(size).fill(false));
    const correctPairs: number[] = [];
    const available = Array.from({ length: size }, (_, i) => i);

    for (let i = 0; i < size; i++) {
      const randomIndex = Math.floor(Math.random() * available.length);
      correctPairs[i] = available[randomIndex];
      available.splice(randomIndex, 1);
      newSolution[i][correctPairs[i]] = true;
    }

    setSolution(newSolution);

    const newGrid: CellState[][] = Array(size).fill(null).map(() => Array(size).fill('empty'));
    setGrid(newGrid);

    const newClues: Clue[] = [];
    for (let i = 0; i < size; i++) {
      const target = correctPairs[i];
      const excluded = correctPairs.filter((_, idx) => idx !== i);

      if (Math.random() > 0.3) {
        newClues.push({
          text: `${selectedItems[i]} matches with position ${target + 1}`,
          color: selectedColors[i]
        });
      } else {
        const excludeIdx = excluded[Math.floor(Math.random() * excluded.length)];
        newClues.push({
          text: `${selectedItems[i]} is NOT in position ${excludeIdx + 1}`,
          color: selectedColors[i]
        });
      }
    }

    setClues(newClues);
    setShowSuccess(false);
  };

  const handleCellClick = (row: number, col: number) => {
    const newGrid = grid.map(r => [...r]);

    if (newGrid[row][col] === 'empty') {
      newGrid[row][col] = 'check';
    } else if (newGrid[row][col] === 'check') {
      newGrid[row][col] = 'x';
    } else {
      newGrid[row][col] = 'empty';
    }

    setGrid(newGrid);
    checkSolution(newGrid);
  };

  const checkSolution = (currentGrid: CellState[][]) => {
    let isCorrect = true;

    for (let i = 0; i < gridSize; i++) {
      for (let j = 0; j < gridSize; j++) {
        const shouldBeChecked = solution[i][j];
        const isChecked = currentGrid[i][j] === 'check';

        if (shouldBeChecked && !isChecked) {
          isCorrect = false;
        }
        if (!shouldBeChecked && isChecked) {
          isCorrect = false;
        }
      }
    }

    if (isCorrect) {
      const hasAllChecks = currentGrid.some(row => row.some(cell => cell === 'check'));
      if (hasAllChecks) {
        const levelScore = 200 + (level * 100);
        setScore(score + levelScore);
        setShowSuccess(true);
      }
    }
  };

  const handleNextLevel = () => {
    setLevel(level + 1);
  };

  const handleFinish = () => {
    const duration = Math.floor((Date.now() - startTime) / 1000);
    onComplete(score, level, duration);
  };

  const renderCell = (row: number, col: number) => {
    const state = grid[row][col];

    return (
      <div
        onClick={() => handleCellClick(row, col)}
        style={{
          width: '60px',
          height: '60px',
          background: state === 'empty' ? '#1a1a2e' : state === 'check' ? '#10b981' : '#ef4444',
          border: '2px solid #334155',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: '24px',
          fontWeight: '700',
          color: '#ffffff',
          transition: 'all 0.2s',
          boxShadow: state !== 'empty' ? '0 0 15px rgba(0, 255, 159, 0.4)' : 'none'
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.borderColor = '#00ff9f';
          e.currentTarget.style.transform = 'scale(1.05)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.borderColor = '#334155';
          e.currentTarget.style.transform = 'scale(1)';
        }}
      >
        {state === 'check' && '✓'}
        {state === 'x' && '✗'}
      </div>
    );
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #0a0a0f 0%, #1a1a2e 50%, #0a0a0f 100%)',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center'
    }}>
      <div style={{
        width: '100%',
        maxWidth: '800px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '20px',
        paddingBottom: '20px',
        borderBottom: '2px solid #00ff9f'
      }}>
        <button
          onClick={onBack}
          style={{
            padding: '10px 20px',
            background: 'transparent',
            border: '2px solid #00ff9f',
            borderRadius: '0px',
            cursor: 'pointer',
            fontWeight: '600',
            color: '#00ff9f',
            fontFamily: 'Courier New, monospace',
            transition: 'all 0.3s',
            boxShadow: '0 0 10px rgba(0, 255, 159, 0.3)'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = '#00ff9f';
            e.currentTarget.style.color = '#0a0a0f';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = 'transparent';
            e.currentTarget.style.color = '#00ff9f';
          }}
        >
          {'<'} BACK
        </button>
        <div style={{
          display: 'flex',
          gap: '20px',
          fontFamily: 'Courier New, monospace',
          color: '#00ff9f'
        }}>
          <div>[LEVEL: {level}]</div>
          <div>[SCORE: {score}]</div>
        </div>
      </div>

      <h1 style={{
        fontSize: '32px',
        fontWeight: '700',
        marginBottom: '30px',
        color: '#00ff9f',
        textShadow: '0 0 20px rgba(0, 255, 159, 0.5)',
        fontFamily: 'Courier New, monospace',
        textAlign: 'center'
      }}>
        {'>'} LOGIC_GRID
      </h1>

      <div style={{
        display: 'flex',
        gap: '30px',
        flexWrap: 'wrap',
        justifyContent: 'center',
        maxWidth: '900px'
      }}>
        <div style={{
          background: 'rgba(0, 255, 159, 0.05)',
          padding: '20px',
          border: '2px solid #00ff9f',
          boxShadow: '0 0 30px rgba(0, 255, 159, 0.3)'
        }}>
          <div style={{
            display: 'grid',
            gridTemplateColumns: `60px repeat(${gridSize}, 60px)`,
            gap: '4px'
          }}>
            <div />
            {categories.map((_cat, idx) => (
              <div key={idx} style={{
                width: '60px',
                height: '40px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '10px',
                fontWeight: '700',
                color: '#00ff9f',
                fontFamily: 'Courier New, monospace',
                textAlign: 'center'
              }}>
                {idx + 1}
              </div>
            ))}

            {categories.map((cat, rowIdx) => (
              <>
                <div key={`label-${rowIdx}`} style={{
                  width: '60px',
                  height: '60px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '10px',
                  fontWeight: '700',
                  color: '#00ff9f',
                  fontFamily: 'Courier New, monospace',
                  textAlign: 'center',
                  padding: '4px'
                }}>
                  {cat}
                </div>
                {Array.from({ length: gridSize }, (_, colIdx) => (
                  <div key={`${rowIdx}-${colIdx}`}>
                    {renderCell(rowIdx, colIdx)}
                  </div>
                ))}
              </>
            ))}
          </div>
        </div>

        <div style={{
          flex: '1',
          minWidth: '280px',
          maxWidth: '350px'
        }}>
          <h3 style={{
            color: '#00ff9f',
            marginBottom: '15px',
            fontFamily: 'Courier New, monospace',
            fontSize: '18px'
          }}>
            [CLUES]
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {clues.map((clue, idx) => (
              <div key={idx} style={{
                background: 'rgba(0, 255, 159, 0.05)',
                border: '2px solid #334155',
                borderLeftColor: clue.color,
                borderLeftWidth: '4px',
                padding: '12px',
                color: '#00ff9f',
                fontFamily: 'Courier New, monospace',
                fontSize: '12px',
                boxShadow: '0 0 10px rgba(0, 0, 0, 0.5)'
              }}>
                {clue.text}
              </div>
            ))}
          </div>

          <div style={{
            marginTop: '20px',
            padding: '15px',
            background: 'rgba(0, 255, 159, 0.05)',
            border: '2px solid #334155',
            color: '#00ff9f',
            fontFamily: 'Courier New, monospace',
            fontSize: '11px',
            lineHeight: '1.6'
          }}>
            <div style={{ marginBottom: '10px', fontWeight: '700' }}>[INSTRUCTIONS]</div>
            <div>• Click cells to cycle: Empty → ✓ → ✗</div>
            <div>• ✓ = Correct match</div>
            <div>• ✗ = Not a match</div>
            <div>• Use clues to deduce answers</div>
          </div>
        </div>
      </div>

      {showSuccess && (
        <div style={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          background: 'rgba(0, 0, 0, 0.95)',
          border: '3px solid #00ff9f',
          borderRadius: '0px',
          padding: '40px',
          textAlign: 'center',
          boxShadow: '0 0 50px rgba(0, 255, 159, 0.6)',
          zIndex: 1000
        }}>
          <h2 style={{
            color: '#00ff9f',
            marginBottom: '20px',
            fontFamily: 'Courier New, monospace',
            fontSize: '28px',
            textShadow: '0 0 20px rgba(0, 255, 159, 0.8)'
          }}>
            [PUZZLE SOLVED!]
          </h2>
          <div style={{ display: 'flex', gap: '15px', justifyContent: 'center' }}>
            <button
              onClick={handleNextLevel}
              style={{
                padding: '15px 30px',
                background: '#00ff9f',
                border: '2px solid #00ff9f',
                borderRadius: '0px',
                cursor: 'pointer',
                fontWeight: '600',
                color: '#0a0a0f',
                fontFamily: 'Courier New, monospace',
                fontSize: '16px',
                transition: 'all 0.3s',
                boxShadow: '0 0 20px rgba(0, 255, 159, 0.5)'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.boxShadow = '0 0 30px rgba(0, 255, 159, 0.9)';
                e.currentTarget.style.transform = 'translateY(-2px)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.boxShadow = '0 0 20px rgba(0, 255, 159, 0.5)';
                e.currentTarget.style.transform = 'translateY(0)';
              }}
            >
              [NEXT LEVEL]
            </button>
            <button
              onClick={handleFinish}
              style={{
                padding: '15px 30px',
                background: 'transparent',
                border: '2px solid #00ff9f',
                borderRadius: '0px',
                cursor: 'pointer',
                fontWeight: '600',
                color: '#00ff9f',
                fontFamily: 'Courier New, monospace',
                fontSize: '16px',
                transition: 'all 0.3s'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = '#00ff9f';
                e.currentTarget.style.color = '#0a0a0f';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = '#00ff9f';
              }}
            >
              [FINISH]
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
