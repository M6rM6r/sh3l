import { useState, useEffect } from 'react';

interface MathMarathonProps {
  onComplete: (score: number, level: number, duration: number) => void;
  onBack: () => void;
}

export function MathMarathon({ onComplete, onBack }: MathMarathonProps) {
  const [level, setLevel] = useState(1);
  const [score, setScore] = useState(0);
  const [question, setQuestion] = useState({ num1: 0, num2: 0, operator: '+', answer: 0 });
  const [userAnswer, setUserAnswer] = useState('');
  const [streak, setStreak] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60);
  const [startTime] = useState(Date.now());
  const [feedback, setFeedback] = useState('');

  useEffect(() => {
    generateQuestion();
  }, [level]);

  useEffect(() => {
    if (timeLeft <= 0) {
      const duration = Math.floor((Date.now() - startTime) / 1000);
      setTimeout(() => onComplete(score, level, duration), 1500);
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => Math.max(0, prev - 1));
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  const generateQuestion = () => {
    const operators = ['+', '-', '*', '/'];
    const operator = operators[Math.floor(Math.random() * Math.min(operators.length, 2 + Math.floor(level / 3)))];

    let num1, num2, answer;

    if (operator === '/') {
      num2 = Math.floor(Math.random() * (5 + level)) + 1;
      answer = Math.floor(Math.random() * (5 + level)) + 1;
      num1 = num2 * answer;
    } else if (operator === '*') {
      num1 = Math.floor(Math.random() * (5 + level)) + 1;
      num2 = Math.floor(Math.random() * (5 + level)) + 1;
      answer = num1 * num2;
    } else {
      num1 = Math.floor(Math.random() * (10 * level)) + 1;
      num2 = Math.floor(Math.random() * (10 * level)) + 1;
      answer = operator === '+' ? num1 + num2 : num1 - num2;
    }

    setQuestion({ num1, num2, operator, answer });
    setUserAnswer('');
    setFeedback('');
  };

  const checkAnswer = () => {
    const isCorrect = parseInt(userAnswer) === question.answer;

    if (isCorrect) {
      const points = 10 * level * (1 + streak * 0.1);
      setScore(Math.floor(score + points));
      setStreak(streak + 1);
      setFeedback('Correct! 🎉');

      if (streak > 0 && streak % 5 === 0) {
        setLevel(level + 1);
      }

      setTimeout(() => generateQuestion(), 500);
    } else {
      setStreak(0);
      setFeedback(`Wrong! Answer was ${question.answer}`);
      setTimeout(() => generateQuestion(), 1500);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && userAnswer) {
      checkAnswer();
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #0a0a0f 0%, #1a1a2e 50%, #0a0a0f 100%)', padding: '20px' }}>
      <div style={{ maxWidth: '600px', margin: '0 auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
          <button onClick={onBack} style={{
            padding: '12px 24px',
            background: 'rgba(255,255,255,0.1)',
            border: '1px solid rgba(0,255,159,0.3)',
            borderRadius: '8px',
            color: '#00ff9f',
            cursor: 'pointer',
            fontSize: '16px'
          }}>← Back</button>
          <h1 style={{ color: '#00ff9f', margin: 0, fontSize: '32px', fontWeight: 'bold' }}>🔢 Math Marathon</h1>
        </div>

        <div style={{ display: 'flex', gap: '15px', marginBottom: '30px', justifyContent: 'center', flexWrap: 'wrap' }}>
          <div style={{
            padding: '15px 25px',
            background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(0,255,159,0.3)',
            borderRadius: '12px',
            fontSize: '18px',
            color: '#fff'
          }}>Level: {level}</div>
          <div style={{
            padding: '15px 25px',
            background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(0,255,159,0.3)',
            borderRadius: '12px',
            fontSize: '18px',
            color: '#fff'
          }}>Score: {score}</div>
          <div style={{
            padding: '15px 25px',
            background: streak >= 5 ? 'rgba(0,255,159,0.2)' : 'rgba(255,255,255,0.05)',
            border: `1px solid ${streak >= 5 ? '#00ff9f' : 'rgba(0,255,159,0.3)'}`,
            borderRadius: '12px',
            fontSize: '18px',
            color: streak >= 5 ? '#00ff9f' : '#fff'
          }}>🔥 {streak}</div>
          <div style={{
            padding: '15px 25px',
            background: timeLeft <= 10 ? 'rgba(255,0,0,0.2)' : 'rgba(255,255,255,0.05)',
            border: `1px solid ${timeLeft <= 10 ? 'rgba(255,0,0,0.5)' : 'rgba(0,255,159,0.3)'}`,
            borderRadius: '12px',
            fontSize: '18px',
            color: timeLeft <= 10 ? '#ff4444' : '#fff'
          }}>⏱ {timeLeft}s</div>
        </div>

        <div style={{
          background: 'rgba(255,255,255,0.05)',
          border: '1px solid rgba(0,255,159,0.3)',
          borderRadius: '16px',
          padding: '60px 40px',
          textAlign: 'center',
          marginBottom: '20px'
        }}>
          <div style={{
            fontSize: '64px',
            color: '#fff',
            marginBottom: '40px',
            fontWeight: 'bold',
            fontFamily: 'monospace'
          }}>
            {question.num1} {question.operator} {question.num2} = ?
          </div>

          <input
            type="number"
            value={userAnswer}
            onChange={(e) => setUserAnswer(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Your answer"
            disabled={timeLeft === 0}
            style={{
              width: '100%',
              padding: '20px',
              fontSize: '32px',
              textAlign: 'center',
              background: 'rgba(255,255,255,0.1)',
              border: '2px solid rgba(0,255,159,0.3)',
              borderRadius: '12px',
              color: '#fff',
              marginBottom: '20px',
              fontFamily: 'monospace'
            }}
            autoFocus
          />

          <button
            onClick={checkAnswer}
            disabled={!userAnswer || timeLeft === 0}
            style={{
              width: '100%',
              padding: '18px',
              background: !userAnswer || timeLeft === 0 ? 'rgba(255,255,255,0.1)' : 'linear-gradient(135deg, #00ff9f 0%, #00cc7f 100%)',
              border: 'none',
              borderRadius: '12px',
              color: !userAnswer || timeLeft === 0 ? '#666' : '#0a0a0f',
              fontSize: '20px',
              fontWeight: 'bold',
              cursor: !userAnswer || timeLeft === 0 ? 'not-allowed' : 'pointer',
              boxShadow: !userAnswer || timeLeft === 0 ? 'none' : '0 4px 20px rgba(0,255,159,0.3)'
            }}
          >
            Submit Answer
          </button>

          {feedback && (
            <div style={{
              marginTop: '20px',
              padding: '15px',
              background: feedback.includes('Correct') ? 'rgba(0,255,159,0.2)' : 'rgba(255,0,0,0.2)',
              border: `1px solid ${feedback.includes('Correct') ? '#00ff9f' : '#ff4444'}`,
              borderRadius: '8px',
              color: feedback.includes('Correct') ? '#00ff9f' : '#ff4444',
              fontSize: '18px',
              fontWeight: 'bold'
            }}>
              {feedback}
            </div>
          )}
        </div>

        {streak >= 5 && (
          <div style={{
            textAlign: 'center',
            color: '#00ff9f',
            fontSize: '18px',
            fontWeight: 'bold',
            animation: 'pulse 1s infinite'
          }}>
            Amazing streak! Keep going! 🚀
          </div>
        )}
      </div>
    </div>
  );
}
