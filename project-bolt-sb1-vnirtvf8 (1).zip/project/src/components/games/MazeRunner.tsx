import { useState, useEffect } from 'react';

interface MazeRunnerProps {
  onComplete: (score: number, level: number, duration: number) => void;
  onBack: () => void;
}

export function MazeRunner({ onComplete, onBack }: MazeRunnerProps) {
  const [level, setLevel] = useState(1);
  const [score, setScore] = useState(0);
  const [playerPos, setPlayerPos] = useState({ x: 1, y: 1 });
  const [exitPos, setExitPos] = useState({ x: 8, y: 8 });
  const [maze, setMaze] = useState<number[][]>([]);
  const [moves, setMoves] = useState(0);
  const [startTime] = useState(Date.now());
  const [timeLeft, setTimeLeft] = useState(60);

  const size = Math.min(10, 8 + Math.floor(level / 3));

  useEffect(() => {
    generateMaze();
  }, [level]);

  useEffect(() => {
    if (timeLeft <= 0) {
      const duration = Math.floor((Date.now() - startTime) / 1000);
      setTimeout(() => onComplete(score, level, duration), 1500);
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => Math.max(0, prev - 1));
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      let newX = playerPos.x;
      let newY = playerPos.y;

      switch (e.key) {
        case 'ArrowUp':
        case 'w':
        case 'W':
          newY -= 1;
          break;
        case 'ArrowDown':
        case 's':
        case 'S':
          newY += 1;
          break;
        case 'ArrowLeft':
        case 'a':
        case 'A':
          newX -= 1;
          break;
        case 'ArrowRight':
        case 'd':
        case 'D':
          newX += 1;
          break;
        default:
          return;
      }

      if (newX >= 0 && newX < size && newY >= 0 && newY < size && maze[newY][newX] === 0) {
        setPlayerPos({ x: newX, y: newY });
        setMoves(moves + 1);

        if (newX === exitPos.x && newY === exitPos.y) {
          const timeBonus = timeLeft * 10;
          const moveBonus = Math.max(0, (size * size - moves) * 5);
          const levelPoints = level * 100;
          setScore(score + levelPoints + timeBonus + moveBonus);
          setLevel(level + 1);
          setTimeLeft(60);
          setMoves(0);
        }
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [playerPos, maze, moves, exitPos]);

  const generateMaze = () => {
    const newMaze: number[][] = Array(size).fill(0).map(() => Array(size).fill(1));

    const carve = (x: number, y: number) => {
      newMaze[y][x] = 0;

      const directions = [
        [0, -2], [0, 2], [-2, 0], [2, 0]
      ].sort(() => Math.random() - 0.5);

      for (const [dx, dy] of directions) {
        const newX = x + dx;
        const newY = y + dy;

        if (newX > 0 && newX < size - 1 && newY > 0 && newY < size - 1 && newMaze[newY][newX] === 1) {
          newMaze[y + dy / 2][x + dx / 2] = 0;
          carve(newX, newY);
        }
      }
    };

    carve(1, 1);
    newMaze[1][1] = 0;
    newMaze[size - 2][size - 2] = 0;

    setMaze(newMaze);
    setPlayerPos({ x: 1, y: 1 });
    setExitPos({ x: size - 2, y: size - 2 });
  };

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #0a0a0f 0%, #1a1a2e 50%, #0a0a0f 100%)', padding: '20px' }}>
      <div style={{ maxWidth: '700px', margin: '0 auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
          <button onClick={onBack} style={{
            padding: '12px 24px',
            background: 'rgba(255,255,255,0.1)',
            border: '1px solid rgba(0,255,159,0.3)',
            borderRadius: '8px',
            color: '#00ff9f',
            cursor: 'pointer',
            fontSize: '16px'
          }}>← Back</button>
          <h1 style={{ color: '#00ff9f', margin: 0, fontSize: '32px', fontWeight: 'bold' }}>🏃 Maze Runner</h1>
        </div>

        <div style={{ display: 'flex', gap: '15px', marginBottom: '30px', justifyContent: 'center', flexWrap: 'wrap' }}>
          <div style={{
            padding: '15px 25px',
            background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(0,255,159,0.3)',
            borderRadius: '12px',
            fontSize: '18px',
            color: '#fff'
          }}>Level: {level}</div>
          <div style={{
            padding: '15px 25px',
            background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(0,255,159,0.3)',
            borderRadius: '12px',
            fontSize: '18px',
            color: '#fff'
          }}>Score: {score}</div>
          <div style={{
            padding: '15px 25px',
            background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(0,255,159,0.3)',
            borderRadius: '12px',
            fontSize: '18px',
            color: '#fff'
          }}>Moves: {moves}</div>
          <div style={{
            padding: '15px 25px',
            background: timeLeft <= 10 ? 'rgba(255,0,0,0.2)' : 'rgba(255,255,255,0.05)',
            border: `1px solid ${timeLeft <= 10 ? 'rgba(255,0,0,0.5)' : 'rgba(0,255,159,0.3)'}`,
            borderRadius: '12px',
            fontSize: '18px',
            color: timeLeft <= 10 ? '#ff4444' : '#fff'
          }}>⏱ {timeLeft}s</div>
        </div>

        <div style={{
          background: 'rgba(255,255,255,0.05)',
          border: '1px solid rgba(0,255,159,0.3)',
          borderRadius: '16px',
          padding: '30px',
          marginBottom: '20px',
          display: 'flex',
          justifyContent: 'center'
        }}>
          <div style={{
            display: 'grid',
            gridTemplateColumns: `repeat(${size}, 1fr)`,
            gap: '2px',
            background: 'rgba(0,0,0,0.5)',
            padding: '5px',
            borderRadius: '8px'
          }}>
            {maze.map((row, y) =>
              row.map((cell, x) => (
                <div
                  key={`${x}-${y}`}
                  style={{
                    width: `${Math.min(40, 400 / size)}px`,
                    height: `${Math.min(40, 400 / size)}px`,
                    background:
                      x === playerPos.x && y === playerPos.y
                        ? 'linear-gradient(135deg, #00ff9f, #00cc7f)'
                        : x === exitPos.x && y === exitPos.y
                          ? 'linear-gradient(135deg, #f59e0b, #d97706)'
                          : cell === 1
                            ? 'rgba(255,255,255,0.1)'
                            : 'rgba(0,0,0,0.3)',
                    borderRadius: '4px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: `${Math.min(24, 240 / size)}px`,
                    boxShadow:
                      x === playerPos.x && y === playerPos.y
                        ? '0 0 20px rgba(0,255,159,0.6)'
                        : x === exitPos.x && y === exitPos.y
                          ? '0 0 20px rgba(245,158,11,0.6)'
                          : 'none'
                  }}
                >
                  {x === playerPos.x && y === playerPos.y && '😊'}
                  {x === exitPos.x && y === exitPos.y && '🎯'}
                </div>
              ))
            )}
          </div>
        </div>

        <div style={{ textAlign: 'center', color: '#999', marginBottom: '10px' }}>
          Use Arrow Keys or WASD to move
        </div>

        <div style={{
          display: 'flex',
          justifyContent: 'center',
          gap: '10px'
        }}>
          <div style={{
            padding: '10px 20px',
            background: 'rgba(0,255,159,0.1)',
            border: '1px solid rgba(0,255,159,0.3)',
            borderRadius: '8px',
            color: '#00ff9f',
            display: 'flex',
            alignItems: 'center',
            gap: '10px'
          }}>
            😊 = You
          </div>
          <div style={{
            padding: '10px 20px',
            background: 'rgba(245,158,11,0.1)',
            border: '1px solid rgba(245,158,11,0.3)',
            borderRadius: '8px',
            color: '#f59e0b',
            display: 'flex',
            alignItems: 'center',
            gap: '10px'
          }}>
            🎯 = Exit
          </div>
        </div>

        {timeLeft === 0 && (
          <div style={{
            marginTop: '20px',
            textAlign: 'center',
            color: '#ff4444',
            fontSize: '24px',
            fontWeight: 'bold'
          }}>
            Time's Up!
          </div>
        )}
      </div>
    </div>
  );
}
