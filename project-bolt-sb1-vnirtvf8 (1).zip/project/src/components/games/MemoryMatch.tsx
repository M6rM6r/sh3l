import { useState, useEffect } from 'react';

interface Card {
  id: number;
  value: string;
  isFlipped: boolean;
  isMatched: boolean;
}

interface MemoryMatchProps {
  onComplete: (score: number, level: number, duration: number) => void;
  onBack: () => void;
}

const emojis = ['🍎', '🍊', '🍋', '🍌', '🍇', '🍓', '🍒', '🍑', '🥝', '🍍', '🥥', '🥭'];

export function MemoryMatch({ onComplete, onBack }: MemoryMatchProps) {
  const [cards, setCards] = useState<Card[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [matches, setMatches] = useState(0);
  const [level] = useState(1);
  const [startTime] = useState(Date.now());
  const [gameOver, setGameOver] = useState(false);

  const pairsCount = Math.min(4 + level, 8);

  useEffect(() => {
    initGame();
  }, [level]);

  const initGame = () => {
    const selectedEmojis = emojis.slice(0, pairsCount);
    const cardPairs = [...selectedEmojis, ...selectedEmojis];
    const shuffled = cardPairs
      .sort(() => Math.random() - 0.5)
      .map((value, index) => ({
        id: index,
        value,
        isFlipped: false,
        isMatched: false,
      }));
    setCards(shuffled);
    setFlippedCards([]);
    setMoves(0);
    setMatches(0);
    setGameOver(false);
  };

  const handleCardClick = (id: number) => {
    if (flippedCards.length === 2 || cards[id].isFlipped || cards[id].isMatched) {
      return;
    }

    const newCards = [...cards];
    newCards[id].isFlipped = true;
    setCards(newCards);

    const newFlipped = [...flippedCards, id];
    setFlippedCards(newFlipped);

    if (newFlipped.length === 2) {
      setMoves(moves + 1);
      const [first, second] = newFlipped;

      if (cards[first].value === cards[second].value) {
        setTimeout(() => {
          const updatedCards = [...cards];
          updatedCards[first].isMatched = true;
          updatedCards[second].isMatched = true;
          setCards(updatedCards);
          setFlippedCards([]);

          const newMatches = matches + 1;
          setMatches(newMatches);

          if (newMatches === pairsCount) {
            const duration = Math.floor((Date.now() - startTime) / 1000);
            const score = Math.max(1000 - moves * 10 - duration * 2, 100);
            setGameOver(true);
            setTimeout(() => onComplete(score, level, duration), 1000);
          }
        }, 500);
      } else {
        setTimeout(() => {
          const updatedCards = [...cards];
          updatedCards[first].isFlipped = false;
          updatedCards[second].isFlipped = false;
          setCards(updatedCards);
          setFlippedCards([]);
        }, 1000);
      }
    }
  };

  const score = Math.max(1000 - moves * 10, 0);

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #0a0a0f 0%, #1a1a2e 50%, #0a0a0f 100%)', padding: '20px' }}>
      <div style={{ maxWidth: '800px', margin: '0 auto' }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '30px',
          color: 'white'
        }}>
          <button
            onClick={onBack}
            style={{
              padding: '10px 20px',
              background: 'white',
              color: '#3B82F6',
              border: 'none',
              borderRadius: '10px',
              cursor: 'pointer',
              fontWeight: '600'
            }}
          >
            ← Back
          </button>
          <h1 style={{ fontSize: '28px', fontWeight: '700', margin: 0 }}>🧠 Memory Match</h1>
          <div style={{ width: '80px' }}></div>
        </div>

        <div style={{
          display: 'flex',
          gap: '20px',
          marginBottom: '30px',
          justifyContent: 'center'
        }}>
          <div style={{
            background: 'rgba(255,255,255,0.2)',
            padding: '15px 25px',
            borderRadius: '10px',
            color: 'white',
            fontWeight: '600'
          }}>
            Level: {level}
          </div>
          <div style={{
            background: 'rgba(255,255,255,0.2)',
            padding: '15px 25px',
            borderRadius: '10px',
            color: 'white',
            fontWeight: '600'
          }}>
            Moves: {moves}
          </div>
          <div style={{
            background: 'rgba(255,255,255,0.2)',
            padding: '15px 25px',
            borderRadius: '10px',
            color: 'white',
            fontWeight: '600'
          }}>
            Score: {score}
          </div>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: `repeat(${Math.ceil(Math.sqrt(pairsCount * 2))}, 1fr)`,
          gap: '15px',
          maxWidth: '600px',
          margin: '0 auto'
        }}>
          {cards.map((card) => (
            <div
              key={card.id}
              onClick={() => handleCardClick(card.id)}
              style={{
                aspectRatio: '1',
                background: card.isFlipped || card.isMatched ? 'white' : 'rgba(255,255,255,0.3)',
                borderRadius: '15px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '48px',
                cursor: card.isMatched ? 'default' : 'pointer',
                transition: 'all 0.3s',
                transform: card.isFlipped || card.isMatched ? 'rotateY(0deg)' : 'rotateY(0deg)',
                opacity: card.isMatched ? 0.6 : 1
              }}
            >
              {(card.isFlipped || card.isMatched) ? card.value : '?'}
            </div>
          ))}
        </div>

        {gameOver && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0,0,0,0.8)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 1000
          }}>
            <div style={{
              background: 'white',
              padding: '40px',
              borderRadius: '20px',
              textAlign: 'center'
            }}>
              <h2 style={{ fontSize: '32px', marginBottom: '20px' }}>Level Complete!</h2>
              <p style={{ fontSize: '18px', color: '#666' }}>Final Score: {score}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
