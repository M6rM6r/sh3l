import { useState, useEffect } from 'react';

interface PatternRecognitionProps {
  onComplete: (score: number, level: number, duration: number) => void;
  onBack: () => void;
}

const shapes = ['●', '■', '▲', '◆', '★'];
const colors = ['#EF4444', '#3B82F6', '#10B981', '#F59E0B', '#8B5CF6'];

interface PatternItem {
  shape: string;
  color: string;
}

export function PatternRecognition({ onComplete, onBack }: PatternRecognitionProps) {
  const [level, setLevel] = useState(1);
  const [pattern, setPattern] = useState<PatternItem[]>([]);
  const [options, setOptions] = useState<PatternItem[]>([]);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);
  const [correctAnswer, setCorrectAnswer] = useState(0);
  const [startTime] = useState(Date.now());
  const [questionsAnswered, setQuestionsAnswered] = useState(0);

  useEffect(() => {
    generatePattern();
  }, [level]);

  const generatePattern = () => {
    const patternLength = 3 + Math.floor(level / 2);
    const newPattern: PatternItem[] = [];

    for (let i = 0; i < patternLength; i++) {
      newPattern.push({
        shape: shapes[i % shapes.length],
        color: colors[i % colors.length]
      });
    }

    const nextItem = {
      shape: shapes[patternLength % shapes.length],
      color: colors[patternLength % colors.length]
    };

    const wrongOptions: PatternItem[] = [];
    while (wrongOptions.length < 3) {
      const option = {
        shape: shapes[Math.floor(Math.random() * shapes.length)],
        color: colors[Math.floor(Math.random() * colors.length)]
      };
      if (option.shape !== nextItem.shape || option.color !== nextItem.color) {
        if (!wrongOptions.some(o => o.shape === option.shape && o.color === option.color)) {
          wrongOptions.push(option);
        }
      }
    }

    const allOptions = [nextItem, ...wrongOptions];
    for (let i = allOptions.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [allOptions[i], allOptions[j]] = [allOptions[j], allOptions[i]];
    }

    setPattern(newPattern);
    setOptions(allOptions);
    setCorrectAnswer(allOptions.findIndex(o => o.shape === nextItem.shape && o.color === nextItem.color));
    setSelectedOption(null);
    setFeedback(null);
  };

  const handleOptionClick = (index: number) => {
    if (feedback !== null) return;

    setSelectedOption(index);

    if (index === correctAnswer) {
      setFeedback('correct');
      const newScore = score + level * 100;
      setScore(newScore);
      const newQuestionsAnswered = questionsAnswered + 1;
      setQuestionsAnswered(newQuestionsAnswered);

      setTimeout(() => {
        if (newQuestionsAnswered >= 10) {
          const duration = Math.floor((Date.now() - startTime) / 1000);
          onComplete(newScore, level, duration);
        } else {
          setLevel(level + 1);
        }
      }, 1000);
    } else {
      setFeedback('wrong');
      setTimeout(() => {
        const duration = Math.floor((Date.now() - startTime) / 1000);
        onComplete(score, level, duration);
      }, 1500);
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #0a0a0f 0%, #1a1a2e 50%, #0a0a0f 100%)', padding: '20px' }}>
      <div style={{ maxWidth: '700px', margin: '0 auto' }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '30px',
          color: 'white'
        }}>
          <button
            onClick={onBack}
            style={{
              padding: '10px 20px',
              background: 'white',
              color: '#EF4444',
              border: 'none',
              borderRadius: '10px',
              cursor: 'pointer',
              fontWeight: '600'
            }}
          >
            ← Back
          </button>
          <h1 style={{ fontSize: '28px', fontWeight: '700', margin: 0 }}>🎯 Pattern Recognition</h1>
          <div style={{ width: '80px' }}></div>
        </div>

        <div style={{
          display: 'flex',
          gap: '20px',
          marginBottom: '40px',
          justifyContent: 'center',
          flexWrap: 'wrap'
        }}>
          <div style={{
            background: 'rgba(255,255,255,0.2)',
            padding: '15px 25px',
            borderRadius: '10px',
            color: 'white',
            fontWeight: '600'
          }}>
            Level: {level}
          </div>
          <div style={{
            background: 'rgba(255,255,255,0.2)',
            padding: '15px 25px',
            borderRadius: '10px',
            color: 'white',
            fontWeight: '600'
          }}>
            Score: {score}
          </div>
          <div style={{
            background: 'rgba(255,255,255,0.2)',
            padding: '15px 25px',
            borderRadius: '10px',
            color: 'white',
            fontWeight: '600'
          }}>
            Progress: {questionsAnswered}/10
          </div>
        </div>

        <div style={{
          background: 'white',
          padding: '40px',
          borderRadius: '20px',
          textAlign: 'center'
        }}>
          <p style={{ fontSize: '18px', color: '#666', marginBottom: '30px' }}>
            What comes next in the pattern?
          </p>

          <div style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            gap: '15px',
            marginBottom: '40px',
            flexWrap: 'wrap'
          }}>
            {pattern.map((item, index) => (
              <div key={index} style={{
                fontSize: '64px',
                color: item.color
              }}>
                {item.shape}
              </div>
            ))}
            <div style={{ fontSize: '64px', color: '#666' }}>?</div>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(2, 1fr)',
            gap: '20px'
          }}>
            {options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleOptionClick(index)}
                disabled={feedback !== null}
                style={{
                  padding: '30px',
                  fontSize: '64px',
                  background: selectedOption === index ?
                    (feedback === 'correct' ? '#D1FAE5' :
                     feedback === 'wrong' ? '#FEE2E2' : '#F3F4F6') : 'white',
                  border: selectedOption === index ?
                    (feedback === 'correct' ? '3px solid #10B981' :
                     feedback === 'wrong' ? '3px solid #EF4444' : '2px solid #e5e7eb') : '2px solid #e5e7eb',
                  borderRadius: '15px',
                  cursor: feedback === null ? 'pointer' : 'not-allowed',
                  transition: 'all 0.3s',
                  color: option.color
                }}
                onMouseEnter={(e) => {
                  if (feedback === null) {
                    e.currentTarget.style.transform = 'scale(1.05)';
                    e.currentTarget.style.background = '#F9FAFB';
                  }
                }}
                onMouseLeave={(e) => {
                  if (feedback === null) {
                    e.currentTarget.style.transform = 'scale(1)';
                    e.currentTarget.style.background = 'white';
                  }
                }}
              >
                {option.shape}
              </button>
            ))}
          </div>

          {feedback === 'correct' && (
            <div style={{
              marginTop: '30px',
              fontSize: '24px',
              color: '#10B981',
              fontWeight: '700'
            }}>
              ✓ Correct!
            </div>
          )}

          {feedback === 'wrong' && (
            <div style={{
              marginTop: '30px',
              fontSize: '24px',
              color: '#EF4444',
              fontWeight: '700'
            }}>
              ✗ Wrong! Game Over
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
