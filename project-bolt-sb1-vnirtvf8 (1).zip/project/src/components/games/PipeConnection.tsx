import { useState, useEffect } from 'react';

interface PipeConnectionProps {
  onComplete: (score: number, level: number, duration: number) => void;
  onBack: () => void;
}

type PipeType = 'empty' | 'straight' | 'corner' | 'start' | 'end';
type Rotation = 0 | 90 | 180 | 270;

interface Pipe {
  type: PipeType;
  rotation: Rotation;
  isConnected: boolean;
}

const GRID_SIZE = 5;

export function PipeConnection({ onComplete, onBack }: PipeConnectionProps) {
  const [grid, setGrid] = useState<Pipe[][]>([]);
  const [level, setLevel] = useState(1);
  const [score, setScore] = useState(0);
  const [startTime] = useState(Date.now());
  const [moves, setMoves] = useState(0);
  const [isComplete, setIsComplete] = useState(false);

  useEffect(() => {
    generateLevel(level);
  }, [level]);

  const generateLevel = (_currentLevel: number) => {
    const newGrid: Pipe[][] = [];

    for (let i = 0; i < GRID_SIZE; i++) {
      newGrid[i] = [];
      for (let j = 0; j < GRID_SIZE; j++) {
        if (i === 0 && j === 0) {
          newGrid[i][j] = { type: 'start', rotation: 0, isConnected: false };
        } else if (i === GRID_SIZE - 1 && j === GRID_SIZE - 1) {
          newGrid[i][j] = { type: 'end', rotation: 0, isConnected: false };
        } else {
          const rand = Math.random();
          let type: PipeType;
          if (rand < 0.3) {
            type = 'empty';
          } else if (rand < 0.65) {
            type = 'straight';
          } else {
            type = 'corner';
          }
          const rotation = [0, 90, 180, 270][Math.floor(Math.random() * 4)] as Rotation;
          newGrid[i][j] = { type, rotation, isConnected: false };
        }
      }
    }

    setGrid(newGrid);
    setIsComplete(false);
  };

  const rotatePipe = (row: number, col: number) => {
    if (grid[row][col].type === 'start' || grid[row][col].type === 'end') return;

    const newGrid = grid.map(r => r.map(p => ({ ...p })));
    const currentRotation = newGrid[row][col].rotation;
    newGrid[row][col].rotation = ((currentRotation + 90) % 360) as Rotation;

    setGrid(newGrid);
    setMoves(moves + 1);

    setTimeout(() => checkConnections(newGrid), 100);
  };

  const checkConnections = (currentGrid: Pipe[][]) => {
    const connected = new Set<string>();
    const queue: [number, number, string][] = [[0, 0, 'right']];
    connected.add('0,0');

    while (queue.length > 0) {
      const [row, col, entryDir] = queue.shift()!;
      const pipe = currentGrid[row][col];

      const exits = getExits(pipe.type, pipe.rotation, entryDir);

      for (const exit of exits) {
        const [newRow, newCol] = getNextPosition(row, col, exit);

        if (newRow >= 0 && newRow < GRID_SIZE && newCol >= 0 && newCol < GRID_SIZE) {
          const key = `${newRow},${newCol}`;
          if (!connected.has(key)) {
            const nextPipe = currentGrid[newRow][newCol];
            const entryToNext = getOppositeDirection(exit);

            if (canConnect(nextPipe.type, nextPipe.rotation, entryToNext)) {
              connected.add(key);
              queue.push([newRow, newCol, entryToNext]);
            }
          }
        }
      }
    }

    const newGrid = currentGrid.map((row, i) =>
      row.map((pipe, j) => ({
        ...pipe,
        isConnected: connected.has(`${i},${j}`)
      }))
    );

    setGrid(newGrid);

    if (connected.has(`${GRID_SIZE - 1},${GRID_SIZE - 1}`)) {
      const bonus = Math.max(0, 100 - moves * 5);
      const levelScore = 100 + bonus + (level * 50);
      setScore(score + levelScore);
      setIsComplete(true);
    }
  };

  const getExits = (type: PipeType, rotation: Rotation, entry: string): string[] => {
    if (type === 'empty') return [];
    if (type === 'start') return ['right'];
    if (type === 'end') return [];

    if (type === 'straight') {
      if (rotation === 0 || rotation === 180) {
        return entry === 'left' ? ['right'] : entry === 'right' ? ['left'] : [];
      } else {
        return entry === 'top' ? ['bottom'] : entry === 'bottom' ? ['top'] : [];
      }
    }

    if (type === 'corner') {
      const corners: Record<Rotation, Record<string, string[]>> = {
        0: { top: ['right'], left: ['bottom'], right: ['top'], bottom: ['left'] },
        90: { top: ['left'], right: ['bottom'], left: ['top'], bottom: ['right'] },
        180: { bottom: ['right'], left: ['top'], right: ['bottom'], top: ['left'] },
        270: { bottom: ['left'], right: ['top'], left: ['bottom'], top: ['right'] }
      };
      return corners[rotation][entry] || [];
    }

    return [];
  };

  const canConnect = (type: PipeType, rotation: Rotation, entry: string): boolean => {
    if (type === 'empty') return false;
    if (type === 'end') return entry === 'top';
    if (type === 'start') return false;

    if (type === 'straight') {
      if (rotation === 0 || rotation === 180) {
        return entry === 'left' || entry === 'right';
      } else {
        return entry === 'top' || entry === 'bottom';
      }
    }

    if (type === 'corner') {
      const validEntries: Record<Rotation, string[]> = {
        0: ['top', 'left'],
        90: ['top', 'right'],
        180: ['bottom', 'left'],
        270: ['bottom', 'right']
      };
      return validEntries[rotation].includes(entry);
    }

    return false;
  };

  const getNextPosition = (row: number, col: number, direction: string): [number, number] => {
    const moves: Record<string, [number, number]> = {
      top: [-1, 0],
      bottom: [1, 0],
      left: [0, -1],
      right: [0, 1]
    };
    const [dRow, dCol] = moves[direction];
    return [row + dRow, col + dCol];
  };

  const getOppositeDirection = (direction: string): string => {
    const opposites: Record<string, string> = {
      top: 'bottom',
      bottom: 'top',
      left: 'right',
      right: 'left'
    };
    return opposites[direction];
  };

  const renderPipe = (pipe: Pipe) => {
    const baseStyle: React.CSSProperties = {
      width: '100%',
      height: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      position: 'relative',
      transform: `rotate(${pipe.rotation}deg)`,
      transition: 'all 0.3s ease'
    };

    const color = pipe.isConnected ? '#00ff9f' : '#334155';
    const glow = pipe.isConnected ? '0 0 15px rgba(0, 255, 159, 0.6)' : 'none';

    if (pipe.type === 'start') {
      return (
        <div style={baseStyle}>
          <div style={{
            width: '40%',
            height: '40%',
            borderRadius: '50%',
            background: '#00ff9f',
            boxShadow: '0 0 20px rgba(0, 255, 159, 0.8)',
            border: '3px solid #00ff9f'
          }} />
        </div>
      );
    }

    if (pipe.type === 'end') {
      return (
        <div style={baseStyle}>
          <div style={{
            width: '40%',
            height: '40%',
            borderRadius: '50%',
            background: pipe.isConnected ? '#00ff9f' : '#1a1a2e',
            boxShadow: pipe.isConnected ? '0 0 20px rgba(0, 255, 159, 0.8)' : 'none',
            border: `3px solid ${color}`,
            transition: 'all 0.3s ease'
          }} />
        </div>
      );
    }

    if (pipe.type === 'straight') {
      return (
        <div style={baseStyle}>
          <div style={{
            width: '100%',
            height: '30%',
            background: color,
            boxShadow: glow
          }} />
        </div>
      );
    }

    if (pipe.type === 'corner') {
      return (
        <div style={baseStyle}>
          <div style={{
            position: 'absolute',
            top: 0,
            left: '35%',
            width: '30%',
            height: '50%',
            background: color,
            boxShadow: glow
          }} />
          <div style={{
            position: 'absolute',
            left: 0,
            top: '35%',
            width: '50%',
            height: '30%',
            background: color,
            boxShadow: glow
          }} />
        </div>
      );
    }

    return <div style={baseStyle} />;
  };

  const handleNextLevel = () => {
    setLevel(level + 1);
    setMoves(0);
  };

  const handleFinish = () => {
    const duration = Math.floor((Date.now() - startTime) / 1000);
    onComplete(score, level, duration);
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #0a0a0f 0%, #1a1a2e 50%, #0a0a0f 100%)',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center'
    }}>
      <div style={{
        width: '100%',
        maxWidth: '600px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '20px',
        paddingBottom: '20px',
        borderBottom: '2px solid #00ff9f'
      }}>
        <button
          onClick={onBack}
          style={{
            padding: '10px 20px',
            background: 'transparent',
            border: '2px solid #00ff9f',
            borderRadius: '0px',
            cursor: 'pointer',
            fontWeight: '600',
            color: '#00ff9f',
            fontFamily: 'Courier New, monospace',
            transition: 'all 0.3s',
            boxShadow: '0 0 10px rgba(0, 255, 159, 0.3)'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = '#00ff9f';
            e.currentTarget.style.color = '#0a0a0f';
            e.currentTarget.style.boxShadow = '0 0 20px rgba(0, 255, 159, 0.6)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = 'transparent';
            e.currentTarget.style.color = '#00ff9f';
            e.currentTarget.style.boxShadow = '0 0 10px rgba(0, 255, 159, 0.3)';
          }}
        >
          {'<'} BACK
        </button>
        <div style={{
          display: 'flex',
          gap: '20px',
          fontFamily: 'Courier New, monospace',
          color: '#00ff9f'
        }}>
          <div>[LEVEL: {level}]</div>
          <div>[SCORE: {score}]</div>
          <div>[MOVES: {moves}]</div>
        </div>
      </div>

      <h1 style={{
        fontSize: '32px',
        fontWeight: '700',
        marginBottom: '30px',
        color: '#00ff9f',
        textShadow: '0 0 20px rgba(0, 255, 159, 0.5)',
        fontFamily: 'Courier New, monospace',
        textAlign: 'center'
      }}>
        {'>'} PIPE_CONNECTION
      </h1>

      <div style={{
        background: 'rgba(0, 255, 159, 0.05)',
        padding: '20px',
        borderRadius: '0px',
        border: '2px solid #00ff9f',
        boxShadow: '0 0 30px rgba(0, 255, 159, 0.3)',
        marginBottom: '20px'
      }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: `repeat(${GRID_SIZE}, 60px)`,
          gridTemplateRows: `repeat(${GRID_SIZE}, 60px)`,
          gap: '4px',
          background: '#0a0a0f',
          padding: '10px',
          border: '2px solid #1a1a2e'
        }}>
          {grid.map((row, i) =>
            row.map((pipe, j) => (
              <div
                key={`${i}-${j}`}
                onClick={() => rotatePipe(i, j)}
                style={{
                  background: '#1a1a2e',
                  cursor: pipe.type !== 'start' && pipe.type !== 'end' ? 'pointer' : 'default',
                  transition: 'all 0.3s',
                  border: '2px solid #334155',
                  position: 'relative'
                }}
                onMouseEnter={(e) => {
                  if (pipe.type !== 'start' && pipe.type !== 'end') {
                    e.currentTarget.style.background = '#2a2a3e';
                    e.currentTarget.style.borderColor = '#00ff9f';
                  }
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = '#1a1a2e';
                  e.currentTarget.style.borderColor = '#334155';
                }}
              >
                {renderPipe(pipe)}
              </div>
            ))
          )}
        </div>
      </div>

      {isComplete && (
        <div style={{
          background: 'rgba(0, 255, 159, 0.1)',
          border: '2px solid #00ff9f',
          borderRadius: '0px',
          padding: '20px',
          marginTop: '20px',
          textAlign: 'center',
          boxShadow: '0 0 30px rgba(0, 255, 159, 0.4)'
        }}>
          <h2 style={{
            color: '#00ff9f',
            marginBottom: '15px',
            fontFamily: 'Courier New, monospace',
            textShadow: '0 0 15px rgba(0, 255, 159, 0.6)'
          }}>
            [LEVEL COMPLETE!]
          </h2>
          <p style={{
            color: '#00ff9f',
            marginBottom: '20px',
            fontFamily: 'Courier New, monospace',
            opacity: 0.8
          }}>
            Moves: {moves} | Bonus: +{Math.max(0, 100 - moves * 5)}
          </p>
          <div style={{ display: 'flex', gap: '15px', justifyContent: 'center' }}>
            <button
              onClick={handleNextLevel}
              style={{
                padding: '12px 24px',
                background: '#00ff9f',
                border: '2px solid #00ff9f',
                borderRadius: '0px',
                cursor: 'pointer',
                fontWeight: '600',
                color: '#0a0a0f',
                fontFamily: 'Courier New, monospace',
                transition: 'all 0.3s',
                boxShadow: '0 0 15px rgba(0, 255, 159, 0.5)'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.boxShadow = '0 0 25px rgba(0, 255, 159, 0.8)';
                e.currentTarget.style.transform = 'translateY(-2px)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.boxShadow = '0 0 15px rgba(0, 255, 159, 0.5)';
                e.currentTarget.style.transform = 'translateY(0)';
              }}
            >
              [NEXT LEVEL]
            </button>
            <button
              onClick={handleFinish}
              style={{
                padding: '12px 24px',
                background: 'transparent',
                border: '2px solid #00ff9f',
                borderRadius: '0px',
                cursor: 'pointer',
                fontWeight: '600',
                color: '#00ff9f',
                fontFamily: 'Courier New, monospace',
                transition: 'all 0.3s',
                boxShadow: '0 0 10px rgba(0, 255, 159, 0.3)'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = '#00ff9f';
                e.currentTarget.style.color = '#0a0a0f';
                e.currentTarget.style.boxShadow = '0 0 20px rgba(0, 255, 159, 0.6)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = '#00ff9f';
                e.currentTarget.style.boxShadow = '0 0 10px rgba(0, 255, 159, 0.3)';
              }}
            >
              [FINISH]
            </button>
          </div>
        </div>
      )}

      <p style={{
        marginTop: '20px',
        color: '#00ff9f',
        opacity: 0.7,
        fontFamily: 'Courier New, monospace',
        textAlign: 'center'
      }}>
        [Click pipes to rotate and connect start to end]
      </p>
    </div>
  );
}
