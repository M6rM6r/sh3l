import { useState, useEffect, useRef } from 'react';

interface QuickReflexesProps {
  onComplete: (score: number, level: number, duration: number) => void;
  onBack: () => void;
}

export function QuickReflexes({ onComplete, onBack }: QuickReflexesProps) {
  const [level, setLevel] = useState(1);
  const [score, setScore] = useState(0);
  const [targets, setTargets] = useState<{ id: number; x: number; y: number; size: number }[]>([]);
  const [nextId, setNextId] = useState(0);
  const [hits, setHits] = useState(0);
  const [misses, setMisses] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [startTime] = useState(Date.now());
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (timeLeft <= 0) {
      const duration = Math.floor((Date.now() - startTime) / 1000);
      setTimeout(() => onComplete(score, level, duration), 1500);
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => Math.max(0, prev - 1));
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  useEffect(() => {
    const spawnInterval = setInterval(() => {
      if (timeLeft > 0 && containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        const size = Math.max(30, 80 - level * 3);

        const target = {
          id: nextId,
          x: Math.random() * (rect.width - size),
          y: Math.random() * (rect.height - size),
          size
        };

        setTargets(prev => [...prev, target]);
        setNextId(nextId + 1);

        setTimeout(() => {
          setTargets(prev => {
            const removed = prev.filter(t => t.id !== target.id);
            if (removed.length < prev.length) {
              setMisses(m => m + 1);
            }
            return removed;
          });
        }, Math.max(500, 1500 - level * 50));
      }
    }, Math.max(300, 800 - level * 30));

    return () => clearInterval(spawnInterval);
  }, [level, nextId, timeLeft]);

  useEffect(() => {
    if (hits > 0 && hits % 10 === 0) {
      setLevel(Math.min(15, level + 1));
    }
  }, [hits]);

  const handleTargetClick = (id: number) => {
    setTargets(prev => prev.filter(t => t.id !== id));
    setHits(hits + 1);
    setScore(score + level * 10);
  };

  const handleMiss = () => {
    setMisses(misses + 1);
  };

  const accuracy = hits + misses > 0 ? Math.round((hits / (hits + misses)) * 100) : 0;

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #0a0a0f 0%, #1a1a2e 50%, #0a0a0f 100%)', padding: '20px' }}>
      <div style={{ maxWidth: '1000px', margin: '0 auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
          <button onClick={onBack} style={{
            padding: '12px 24px',
            background: 'rgba(255,255,255,0.1)',
            border: '1px solid rgba(0,255,159,0.3)',
            borderRadius: '8px',
            color: '#00ff9f',
            cursor: 'pointer',
            fontSize: '16px'
          }}>← Back</button>
          <h1 style={{ color: '#00ff9f', margin: 0, fontSize: '32px', fontWeight: 'bold' }}>⚡ Quick Reflexes</h1>
        </div>

        <div style={{ display: 'flex', gap: '15px', marginBottom: '30px', justifyContent: 'center', flexWrap: 'wrap' }}>
          <div style={{
            padding: '15px 25px',
            background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(0,255,159,0.3)',
            borderRadius: '12px',
            fontSize: '18px',
            color: '#fff'
          }}>Level: {level}</div>
          <div style={{
            padding: '15px 25px',
            background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(0,255,159,0.3)',
            borderRadius: '12px',
            fontSize: '18px',
            color: '#fff'
          }}>Score: {score}</div>
          <div style={{
            padding: '15px 25px',
            background: 'rgba(0,255,159,0.1)',
            border: '1px solid rgba(0,255,159,0.3)',
            borderRadius: '12px',
            fontSize: '18px',
            color: '#00ff9f'
          }}>✓ {hits}</div>
          <div style={{
            padding: '15px 25px',
            background: 'rgba(255,0,0,0.1)',
            border: '1px solid rgba(255,0,0,0.3)',
            borderRadius: '12px',
            fontSize: '18px',
            color: '#ff4444'
          }}>✗ {misses}</div>
          <div style={{
            padding: '15px 25px',
            background: accuracy >= 80 ? 'rgba(0,255,159,0.1)' : 'rgba(255,255,255,0.05)',
            border: `1px solid ${accuracy >= 80 ? 'rgba(0,255,159,0.3)' : 'rgba(255,255,255,0.3)'}`,
            borderRadius: '12px',
            fontSize: '18px',
            color: accuracy >= 80 ? '#00ff9f' : '#fff'
          }}>🎯 {accuracy}%</div>
          <div style={{
            padding: '15px 25px',
            background: timeLeft <= 10 ? 'rgba(255,0,0,0.2)' : 'rgba(255,255,255,0.05)',
            border: `1px solid ${timeLeft <= 10 ? 'rgba(255,0,0,0.5)' : 'rgba(0,255,159,0.3)'}`,
            borderRadius: '12px',
            fontSize: '18px',
            color: timeLeft <= 10 ? '#ff4444' : '#fff'
          }}>⏱ {timeLeft}s</div>
        </div>

        <div
          ref={containerRef}
          onClick={handleMiss}
          style={{
            position: 'relative',
            width: '100%',
            height: '500px',
            background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(0,255,159,0.3)',
            borderRadius: '16px',
            overflow: 'hidden',
            cursor: 'crosshair'
          }}
        >
          {targets.map(target => (
            <div
              key={target.id}
              onClick={(e) => {
                e.stopPropagation();
                handleTargetClick(target.id);
              }}
              style={{
                position: 'absolute',
                left: `${target.x}px`,
                top: `${target.y}px`,
                width: `${target.size}px`,
                height: `${target.size}px`,
                borderRadius: '50%',
                background: 'radial-gradient(circle, #00ff9f, #00cc7f)',
                cursor: 'pointer',
                boxShadow: '0 0 20px rgba(0,255,159,0.6), inset 0 0 10px rgba(255,255,255,0.3)',
                animation: 'pulse 0.5s infinite',
                border: '3px solid rgba(255,255,255,0.5)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: `${target.size * 0.6}px`
              }}
            >
              🎯
            </div>
          ))}

          {timeLeft === 0 && (
            <div style={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              textAlign: 'center',
              color: '#fff',
              fontSize: '32px',
              fontWeight: 'bold',
              background: 'rgba(0,0,0,0.8)',
              padding: '40px',
              borderRadius: '16px',
              border: '2px solid #00ff9f'
            }}>
              <div style={{ marginBottom: '20px' }}>Time's Up!</div>
              <div style={{ fontSize: '24px', color: '#00ff9f' }}>
                Final Score: {score}
              </div>
              <div style={{ fontSize: '18px', color: '#999', marginTop: '10px' }}>
                Accuracy: {accuracy}%
              </div>
            </div>
          )}
        </div>

        <div style={{
          marginTop: '20px',
          textAlign: 'center',
          color: '#999',
          fontSize: '16px'
        }}>
          Click the targets as fast as you can! They disappear quickly!
        </div>
      </div>

      <style>
        {`
          @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
          }
        `}
      </style>
    </div>
  );
}
