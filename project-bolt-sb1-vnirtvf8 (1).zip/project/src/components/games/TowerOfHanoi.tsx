import { useState, useEffect } from 'react';

interface TowerOfHanoiProps {
  onComplete: (score: number, level: number, duration: number) => void;
  onBack: () => void;
}

interface Disk {
  size: number;
  color: string;
}

export function TowerOfHanoi({ onComplete, onBack }: TowerOfHanoiProps) {
  const [towers, setTowers] = useState<Disk[][]>([[], [], []]);
  const [selectedTower, setSelectedTower] = useState<number | null>(null);
  const [moves, setMoves] = useState(0);
  const [level, setLevel] = useState(1);
  const [score, setScore] = useState(0);
  const [startTime] = useState(Date.now());
  const [diskCount, setDiskCount] = useState(3);
  const [minMoves, setMinMoves] = useState(7);
  const [showSuccess, setShowSuccess] = useState(false);

  const DISK_COLORS = [
    '#ef4444', '#f97316', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6', '#ec4899', '#06b6d4'
  ];

  useEffect(() => {
    initializeLevel(level);
  }, [level]);

  const initializeLevel = (currentLevel: number) => {
    const disks = Math.min(3 + Math.floor(currentLevel / 2), 8);
    setDiskCount(disks);
    setMinMoves(Math.pow(2, disks) - 1);

    const initialTower: Disk[] = [];
    for (let i = disks; i >= 1; i--) {
      initialTower.push({
        size: i,
        color: DISK_COLORS[i - 1]
      });
    }

    setTowers([initialTower, [], []]);
    setMoves(0);
    setSelectedTower(null);
    setShowSuccess(false);
  };

  const handleTowerClick = (towerIndex: number) => {
    if (selectedTower === null) {
      if (towers[towerIndex].length > 0) {
        setSelectedTower(towerIndex);
      }
    } else {
      if (selectedTower === towerIndex) {
        setSelectedTower(null);
        return;
      }

      const fromTower = towers[selectedTower];
      const toTower = towers[towerIndex];

      if (fromTower.length === 0) {
        setSelectedTower(null);
        return;
      }

      const diskToMove = fromTower[fromTower.length - 1];

      if (toTower.length === 0 || diskToMove.size < toTower[toTower.length - 1].size) {
        const newTowers = towers.map(tower => [...tower]);
        newTowers[selectedTower].pop();
        newTowers[towerIndex].push(diskToMove);

        setTowers(newTowers);
        setMoves(moves + 1);
        setSelectedTower(null);

        if (newTowers[2].length === diskCount) {
          const efficiency = minMoves / (moves + 1);
          const bonus = Math.floor(efficiency * 200);
          const levelScore = 400 + bonus + (level * 150);
          setScore(score + levelScore);
          setShowSuccess(true);
        }
      } else {
        setSelectedTower(null);
      }
    }
  };

  const handleReset = () => {
    initializeLevel(level);
  };

  const handleNextLevel = () => {
    setLevel(level + 1);
  };

  const handleFinish = () => {
    const duration = Math.floor((Date.now() - startTime) / 1000);
    onComplete(score, level, duration);
  };

  const renderDisk = (disk: Disk) => {
    const width = 40 + (disk.size * 25);

    return (
      <div
        style={{
          width: `${width}px`,
          height: '30px',
          background: disk.color,
          border: '3px solid #334155',
          borderRadius: '8px',
          boxShadow: `0 0 20px ${disk.color}60, inset 0 -5px 10px rgba(0,0,0,0.3)`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontFamily: 'Courier New, monospace',
          fontWeight: '700',
          color: '#ffffff',
          fontSize: '14px',
          transition: 'all 0.2s',
          position: 'relative',
          zIndex: 10 - disk.size
        }}
      >
        {disk.size}
      </div>
    );
  };

  const renderTower = (towerIndex: number) => {
    const tower = towers[towerIndex];
    const isSelected = selectedTower === towerIndex;
    const canReceive = selectedTower !== null && selectedTower !== towerIndex &&
                       towers[selectedTower].length > 0 &&
                       (tower.length === 0 || towers[selectedTower][towers[selectedTower].length - 1].size < tower[tower.length - 1].size);

    return (
      <div
        onClick={() => handleTowerClick(towerIndex)}
        style={{
          flex: 1,
          minWidth: '200px',
          height: '400px',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'flex-end',
          alignItems: 'center',
          position: 'relative',
          cursor: 'pointer',
          padding: '20px',
          background: isSelected ? 'rgba(0, 255, 159, 0.1)' : canReceive ? 'rgba(16, 185, 129, 0.1)' : 'transparent',
          border: isSelected ? '3px solid #00ff9f' : canReceive ? '3px dashed #10b981' : '2px solid #334155',
          borderRadius: '8px',
          transition: 'all 0.3s'
        }}
        onMouseEnter={(e) => {
          if (!isSelected) {
            e.currentTarget.style.borderColor = '#00ff9f';
            e.currentTarget.style.background = 'rgba(0, 255, 159, 0.05)';
          }
        }}
        onMouseLeave={(e) => {
          if (!isSelected) {
            e.currentTarget.style.borderColor = '#334155';
            e.currentTarget.style.background = 'transparent';
          }
        }}
      >
        <div style={{
          position: 'absolute',
          top: '20px',
          fontFamily: 'Courier New, monospace',
          color: '#00ff9f',
          fontWeight: '700',
          fontSize: '14px'
        }}>
          [TOWER {towerIndex + 1}]
        </div>

        <div style={{
          position: 'absolute',
          bottom: '0',
          width: '4px',
          height: '100%',
          background: 'linear-gradient(to top, #00ff9f, transparent)',
          opacity: 0.5
        }} />

        <div style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '5px',
          marginBottom: '10px'
        }}>
          {tower.map((disk, idx) => (
            <div key={idx}>
              {renderDisk(disk)}
            </div>
          ))}
        </div>

        <div style={{
          width: '100%',
          height: '20px',
          background: 'linear-gradient(to right, #1a1a2e, #00ff9f, #1a1a2e)',
          border: '2px solid #00ff9f',
          boxShadow: '0 0 20px rgba(0, 255, 159, 0.5)',
          borderRadius: '4px'
        }} />
      </div>
    );
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #0a0a0f 0%, #1a1a2e 50%, #0a0a0f 100%)',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center'
    }}>
      <div style={{
        width: '100%',
        maxWidth: '900px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '20px',
        paddingBottom: '20px',
        borderBottom: '2px solid #00ff9f'
      }}>
        <button
          onClick={onBack}
          style={{
            padding: '10px 20px',
            background: 'transparent',
            border: '2px solid #00ff9f',
            borderRadius: '0px',
            cursor: 'pointer',
            fontWeight: '600',
            color: '#00ff9f',
            fontFamily: 'Courier New, monospace',
            transition: 'all 0.3s',
            boxShadow: '0 0 10px rgba(0, 255, 159, 0.3)'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = '#00ff9f';
            e.currentTarget.style.color = '#0a0a0f';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = 'transparent';
            e.currentTarget.style.color = '#00ff9f';
          }}
        >
          {'<'} BACK
        </button>
        <div style={{
          display: 'flex',
          gap: '20px',
          fontFamily: 'Courier New, monospace',
          color: '#00ff9f'
        }}>
          <div>[LEVEL: {level}]</div>
          <div>[SCORE: {score}]</div>
          <div>[MOVES: {moves}/{minMoves}]</div>
        </div>
      </div>

      <h1 style={{
        fontSize: '32px',
        fontWeight: '700',
        marginBottom: '10px',
        color: '#00ff9f',
        textShadow: '0 0 20px rgba(0, 255, 159, 0.5)',
        fontFamily: 'Courier New, monospace',
        textAlign: 'center'
      }}>
        {'>'} TOWER_OF_HANOI
      </h1>

      <p style={{
        color: '#00ff9f',
        opacity: 0.7,
        fontFamily: 'Courier New, monospace',
        marginBottom: '30px',
        textAlign: 'center'
      }}>
        [Move all {diskCount} disks to Tower 3]
      </p>

      <div style={{
        background: 'rgba(0, 255, 159, 0.05)',
        padding: '30px',
        border: '2px solid #00ff9f',
        boxShadow: '0 0 30px rgba(0, 255, 159, 0.3)',
        marginBottom: '20px',
        width: '100%',
        maxWidth: '900px'
      }}>
        <div style={{
          display: 'flex',
          gap: '20px',
          justifyContent: 'center',
          marginBottom: '30px'
        }}>
          {[0, 1, 2].map(towerIndex => renderTower(towerIndex))}
        </div>

        <button
          onClick={handleReset}
          style={{
            width: '100%',
            padding: '12px',
            background: 'transparent',
            border: '2px solid #ef4444',
            color: '#ef4444',
            cursor: 'pointer',
            fontWeight: '600',
            fontFamily: 'Courier New, monospace',
            transition: 'all 0.3s'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = '#ef4444';
            e.currentTarget.style.color = '#0a0a0f';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = 'transparent';
            e.currentTarget.style.color = '#ef4444';
          }}
        >
          [RESET PUZZLE]
        </button>
      </div>

      <div style={{
        width: '100%',
        maxWidth: '900px',
        padding: '15px',
        background: 'rgba(0, 255, 159, 0.05)',
        border: '2px solid #334155',
        color: '#00ff9f',
        fontFamily: 'Courier New, monospace',
        fontSize: '12px',
        lineHeight: '1.8'
      }}>
        <div style={{ fontWeight: '700', marginBottom: '10px' }}>[RULES]</div>
        <div>• Move all disks from Tower 1 to Tower 3</div>
        <div>• Only one disk can be moved at a time</div>
        <div>• Larger disks cannot be placed on smaller disks</div>
        <div>• Minimum moves possible: {minMoves}</div>
      </div>

      {showSuccess && (
        <div style={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          background: 'rgba(0, 0, 0, 0.95)',
          border: '3px solid #00ff9f',
          padding: '40px',
          textAlign: 'center',
          boxShadow: '0 0 50px rgba(0, 255, 159, 0.6)',
          zIndex: 1000
        }}>
          <h2 style={{
            color: '#00ff9f',
            marginBottom: '15px',
            fontFamily: 'Courier New, monospace',
            fontSize: '28px',
            textShadow: '0 0 20px rgba(0, 255, 159, 0.8)'
          }}>
            [PUZZLE SOLVED!]
          </h2>
          <p style={{
            color: '#00ff9f',
            opacity: 0.8,
            fontFamily: 'Courier New, monospace',
            marginBottom: '10px'
          }}>
            Completed in {moves} moves
          </p>
          <p style={{
            color: moves === minMoves ? '#10b981' : '#f59e0b',
            fontFamily: 'Courier New, monospace',
            marginBottom: '25px',
            fontSize: '14px'
          }}>
            {moves === minMoves ? '[PERFECT! Optimal solution]' : `[${Math.floor((minMoves / moves) * 100)}% efficiency]`}
          </p>
          <div style={{ display: 'flex', gap: '15px', justifyContent: 'center' }}>
            <button
              onClick={handleNextLevel}
              style={{
                padding: '15px 30px',
                background: '#00ff9f',
                border: '2px solid #00ff9f',
                cursor: 'pointer',
                fontWeight: '600',
                color: '#0a0a0f',
                fontFamily: 'Courier New, monospace',
                fontSize: '16px',
                transition: 'all 0.3s',
                boxShadow: '0 0 20px rgba(0, 255, 159, 0.5)'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.boxShadow = '0 0 30px rgba(0, 255, 159, 0.9)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.boxShadow = '0 0 20px rgba(0, 255, 159, 0.5)';
              }}
            >
              [NEXT LEVEL]
            </button>
            <button
              onClick={handleFinish}
              style={{
                padding: '15px 30px',
                background: 'transparent',
                border: '2px solid #00ff9f',
                cursor: 'pointer',
                fontWeight: '600',
                color: '#00ff9f',
                fontFamily: 'Courier New, monospace',
                fontSize: '16px',
                transition: 'all 0.3s'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = '#00ff9f';
                e.currentTarget.style.color = '#0a0a0f';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = '#00ff9f';
              }}
            >
              [FINISH]
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
